export PATH=$PWD/bin:$PATH CONF_DIR=$PWD/c IPSEC_CONF=$PWD/ipsec.conf IPSEC_D=$PWD/ipd PPP_DIR=$PWD/ppp XL2TPD_CONF=$PWD/x/x.conf SECRETS=$PWD/sec NO_RESTART=1 STATE_DIR=$PWD/st UNIT_DIR=$PWD/units L2TP_GW=$PWD/../build/l2tp-gw SYS_NET=/sys/class/net IPSEC_RECHECK_WAIT=0
rm -rf c ipd ppp x st units ipt calls sec ipsec.conf run cj
mkdir -p c ipd ppp/ip-up.d x st/traffic/daily st/quality units run
printf '#!/bin/sh\n' > ppp/ip-up; printf '#!/bin/sh\n' > ppp/ip-down
echo "include $IPSEC_D/*.conf" > ipsec.conf
cp ../t8/c/web.conf c/
ok(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fi; }
ip link set lo up
echo "Security Associations (0 up, 0 connecting):" > ipsec.status
printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\nquota_gb = 5\nquota_period = month\n\n[cl2]\nhost = 8.8.8.8\npsk = p2\nuser = c2\npass = c2p\n' > c/sites.conf
python3 - <<'PY'
import datetime,random
random.seed(2); t=datetime.date.today()
for n,k in (("cl",1.0),("cl2",.3)):
    with open("st/traffic/daily/%s.csv"%n,"w") as f:
        for i in range(100,-1,-1):
            d=t-datetime.timedelta(days=i); f.write("%s,%d,%d\n"%(d.isoformat(),int(random.uniform(1e8,9e8)*k),int(random.uniform(1e7,1e8)*k)))
PY
date +%s > st/traffic/heartbeat
python3 - <<'PY'
import time
now=int(time.time()); rx=tx=1000
L=[]
for k in range(30,0,-1):
    rx+=1000; tx+=2000; L.append("%d up 0 20 30 3 0 18 25 %d %d"%(now-k*60,rx,tx))
open("st/quality/cl.log","w").write("\n".join(L)+"\n")
PY
python3 -I ../build/l2tp-gw-web run >/dev/null 2>&1 & W=$!; sleep 1.5
B=http://127.0.0.1:18082; J=cj; C=/usr/bin/curl
PW=$(sed -n 's/^password *= *//p' c/web.conf | head -1)
$C -s -c $J -b $J -L --data-urlencode "password=$PW" $B/login > main.html
get(){ $C -s -b $J -c $J "$@"; }
echo "--- traffic"
get $B/traffic > tr.html; get "$B/traffic?w=7" > tr7.html; get "$B/traffic?w=90" > tr90.html; get "$B/traffic?name=cl" > td.html; get "$B/traffic?name=zzz" > tbad.html
ok "overview has totals, chart and table" "grep -q 'All connections together' tr.html && grep -q 'qtab tsort' tr.html && grep -q 'This month' tr.html"
ok "overview lists both connections with row links" "grep -q \"location='/traffic?name=cl'\" tr.html && grep -q \"location='/traffic?name=cl2'\" tr.html"
ok "chart has 30 / 7 / 90 bars" "[ \$(grep -o 'class=td' tr.html | wc -l) = 30 ] && [ \$(grep -o 'class=td' tr7.html | wc -l) = 7 ] && [ \$(grep -o 'class=td' tr90.html | wc -l) = 90 ]"
ok "tabs mark the chosen window" "grep -q \"tab on' href='/traffic?x=1&w=7\" tr7.html"
ok "Archive and CSV buttons stay" "grep -q '>Archive<' tr.html && grep -q 'Download all as CSV' tr.html"
ok "sortable header script is present" "grep -q 'function tsort' tr.html"
ok "detail: totals, per-day chart, numbers, limit, daily table, reset" "grep -q 'Per day' td.html && grep -q 'Average per day' td.html && grep -q 'Busiest day' td.html && grep -q 'Traffic limit' td.html && grep -q 'Daily table' td.html && grep -q 'Reset all numbers of this connection' td.html"
ok "detail: this month vs last month" "grep -q 'in the whole last month' td.html"
ok "unknown connection handled" "grep -q 'Unknown connection' tbad.html"
ok "numbers: busiest day equals the real maximum" "python3 - <<'PY'
import csv,re
rows=[(l.split(',')[0],int(l.split(',')[1])+int(l.split(',')[2])) for l in open('st/traffic/daily/cl.csv')]
d=max(rows,key=lambda x:x[1])[0]
raise SystemExit(0 if d in open('td.html').read() else 1)
PY"
echo "--- health inside Quality"
get $B/quality > q.html; get "$B/conn?name=cl" > conn.html; get -o /dev/null -w '%{http_code} %{redirect_url}\n' $B/check > chk.txt
ok "Quality has the server and services card" "grep -q 'Server and services' q.html"
ok "each connection has a health line" "grep -q 'Health: ' q.html"
ok "a broken tunnel shows its first problem in the list" "grep -q 'class=hp' q.html"
ok "connection page has a Health check card with a Check again button" "grep -q '<h2>Health check' conn.html && grep -q 'recheck=1' conn.html"
ok "connection page has the Traffic card" "grep -q '<h2>Traffic' conn.html && grep -q 'All traffic numbers' conn.html"
ok "/check redirects to Quality" "grep -q '303 .*quality' chk.txt"
ok "menu has no Health check item any more" "! grep -q \"<a href='/check'\" q.html"
ok "recheck parameter works" "get '$B/quality?recheck=1' | grep -q 'Server and services'"
ok "no python error" "! grep -qi traceback tr.html td.html q.html conn.html"
for f in tr.html td.html q.html conn.html; do python3 - $f <<'PY'
import sys
s=open(sys.argv[1]).read()
assert s.count('<svg')==s.count('</svg>')
PY
[ $? = 0 ] && echo "PASS svg balanced $f" || echo "FAIL svg balanced $f"; done
echo "--- reset still works"
CS=$(grep -o "name=csrf value='[^']*'" td.html | head -1 | sed "s/.*value='//;s/'//")
$C -s -b $J -c $J -d "csrf=$CS" -d name=cl -d all=1 $B/traffic/reset -o /dev/null -w '%{http_code}\n' > rs.txt
sleep 0.5
ok "reset of one connection answers with a redirect" "grep -q '303' rs.txt"
kill $W
