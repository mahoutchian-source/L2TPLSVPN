sites.conf
sites.conf.bak
web.conf
ioctl(TUNSETIFF): Device or resource busy
Error: ipv4: Address already assigned.
>Routes<
--- routes empty
No rules yet
No lists yet
--- new list bad entry
warnbox>line 2: not an IPv4 address, network, range or DNS name  (notanip)<br>line 3: 0.0.0.0
--- new list good
303 http://127.0.0.1:18082/routes/review
Review: List iran
Added</b>0
confirm 303
4 entries (6 networks, 1 DNS name)
--- rule add (bad / good)
Next hop looks like 172.17.192.3 or 172.17.192.3@site, and the metric is a number 1-65535.
Added</b>13
Total after</b>13
10.20.0.0/22 dev ppp-a scope link metric 2 linkdown 
10.20.4.0/23 dev ppp-a scope link metric 2 linkdown 
10.20.6.0/24 dev ppp-a scope link metric 2 linkdown 
10.20.8.0/21 dev ppp-a scope link metric 2 linkdown 
10.20.16.0/20 dev ppp-a scope link metric 2 linkdown 
10.20.32.0/19 dev ppp-a scope link metric 2 linkdown 
10.20.64.0/18 dev ppp-a scope link metric 2 linkdown 
10.20.128.0/17 dev ppp-a scope link metric 2 linkdown 
10.30.1.1 dev ppp-a scope link metric 2 linkdown 
10.30.1.2/31 dev ppp-a scope link metric 2 linkdown 
iran via 172.17.192.3: done. 13 routes are in place.
Active
iran via 172.17.192.3 metric 2'>
--- toggle off
0
13
--- delete list in use refused
is used by 1 rule(s). Delete those rules first.
--- protect
Added</b>0
13
Not an IPv4 address or network: zzz
--- cancel
# managed by l2tp-gw-web (Routes page). Format:  LIST via IP[@site] metric N [disabled]
iran via 172.17.192.3 metric 2
protect 10.20.7.0/24
--- delete rule then list
0
--- big list (400KB)
288818 big.txt
303
Review: List big
--- csrf missing
routes/list/save 403
routes/list/delete 403
routes/rule/add 403
routes/rule/delete 403
routes/rule/toggle 403
routes/protect 403
routes/confirm 403
routes/cancel 403
--- unauth
200
--- unknown list edit
Unknown list
