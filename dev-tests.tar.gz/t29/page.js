
(function(){var c=document.getElementById('clk');if(!c)return;var base=+c.getAttribute('data-ms'),t0=Date.now(),tz=c.getAttribute('data-tz')||'UTC';
 function f(){var d=new Date(base+Date.now()-t0),o;try{o=new Intl.DateTimeFormat('en-GB',{timeZone:tz,weekday:'short',day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(d)}catch(e){o=d.toISOString().replace('T',' ').slice(0,19)}
  c.textContent=o+' ('+tz+')'}
 f();setInterval(f,1000)})();
function toast(t){var x=document.getElementById('toast');x.textContent=t;x.style.display='block';clearTimeout(window._t);window._t=setTimeout(function(){x.style.display='none'},9000)}
function ping(n,b){b.disabled=true;var o=b.textContent;b.textContent='Pinging...';
 fetch('/ping?name='+encodeURIComponent(n),{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(j){toast(j.text)})
 .catch(function(){toast('Ping request failed')}).then(function(){b.disabled=false;b.textContent=o})}
function refresh(){var l=document.getElementById('live');if(!l)return;
 fetch('/live'+(l.getAttribute('data-src')||''),{credentials:'same-origin'}).then(function(r){if(r.status!==200)throw 0;return r.json()}).then(function(j){
  l.innerHTML=j.html;var rw=document.getElementById('raw');if(rw)rw.textContent=j.raw;applySpeed()}).catch(function(){})}
if(document.getElementById('live'))setInterval(refresh,10000);
document.addEventListener('submit',function(e){var b=e.target.querySelector('[data-busy]');
 if(b){b.disabled=true;b.textContent=b.getAttribute('data-busy')}});

var HIST={},TOT=[];
function spath(a,w,h,mx){var n=a.length;if(n<2)return['',''];var st=w/(n-1),off=0,d='';for(var i=0;i<n;i++){var x=(off+i)*st,y=h-2-(mx>0?a[i]/mx:0)*(h-6);d+=(i?'L':'M')+x.toFixed(1)+' '+y.toFixed(1)}
 return [d,d+'L'+((off+n-1)*st).toFixed(1)+' '+h+'L'+(off*st).toFixed(1)+' '+h+'Z']}
function drawSparks(){var els=document.querySelectorAll('svg.spark[data-spark]');for(var i=0;i<els.length;i++){var a=HIST[els[i].getAttribute('data-spark')]||[];
 var mx=Math.max.apply(null,a.concat([1e3])),p=spath(a,200,30,mx);els[i].innerHTML=p[0]?'<path class=f d="'+p[1]+'"/><path class=a d="'+p[0]+'"/>':''}
 var c=document.getElementById('totchart');if(c){var dn=TOT.map(function(x){return x[0]}),up=TOT.map(function(x){return x[1]}),m=Math.max.apply(null,dn.concat(up,[1e3]));
 var a=spath(dn,300,96,m),b=spath(up,300,96,m);c.innerHTML=a[0]?'<path d="'+a[1]+'" fill="var(--accent)" opacity=".22"/><path d="'+a[0]+'" fill="none" stroke="var(--accent)" stroke-width="1.8"/><path d="'+b[0]+'" fill="none" stroke="var(--ok)" stroke-width="1.8"/>':'';
 var nn=document.getElementById('totnone');if(nn)nn.style.display=a[0]?'none':'block';c.style.display=a[0]?'block':'none';var t=document.getElementById('tottxt');if(t&&TOT.length){var l=TOT[TOT.length-1];t.textContent='now '+fmtbps(l[0]+l[1])}}}
var SP={},PREV=null;
function fmtbps(v){if(v>=1e6)return (v/1e6).toFixed(2)+' Mb/s';if(v>=1e3)return (v/1e3).toFixed(1)+' Kb/s';return Math.round(v)+' b/s'}
function applySpeed(){drawSparks();var els=document.querySelectorAll('[data-speed]');for(var i=0;i<els.length;i++){var t=SP[els[i].getAttribute('data-speed')];if(t)els[i].innerHTML=t}}
function speed(){fetch('/speed',{credentials:'same-origin'}).then(function(r){if(r.status!==200)throw 0;return r.json()}).then(function(j){
 var td=0,tu=0;if(PREV&&j.t>PREV.t){var dt=j.t-PREV.t;for(var n in j.links){var a=PREV.links[n],b=j.links[n];
  if(a&&b&&b.tx>=a.tx&&b.rx>=a.rx){var dn=(b.tx-a.tx)*8/dt,upv=(b.rx-a.rx)*8/dt;SP[n]='&darr; '+fmtbps(dn)+' &nbsp;&uarr; '+fmtbps(upv);if(n!=='__nic'){var h=HIST[n]=HIST[n]||[];h.push(dn+upv);if(h.length>60)h.shift();td+=dn;tu+=upv}}}}
 if(PREV&&j.t>PREV.t){TOT.push([td,tu]);if(TOT.length>60)TOT.shift()}
 PREV=j;applySpeed()}).catch(function(){})}
if(document.getElementById('live'))setInterval(speed,2000);
function toggleTheme(){var d=document.documentElement,c=d.getAttribute('data-theme');
 if(!c)c=(window.matchMedia&&matchMedia('(prefers-color-scheme: light)').matches)?'light':'dark';
 var n=c==='dark'?'light':'dark';d.setAttribute('data-theme',n);try{localStorage.setItem('theme',n)}catch(e){}}
function tsort(th){var t=th.closest('table'),i=th.cellIndex,b=t.tBodies[0],r=[].slice.call(b.rows),d=th.getAttribute('data-dir')==='d'?'a':'d';[].forEach.call(t.querySelectorAll('th'),function(x){x.removeAttribute('data-dir')});th.setAttribute('data-dir',d);r.sort(function(a,c){var x=a.cells[i].getAttribute('data-v'),y=c.cells[i].getAttribute('data-v'),nx=parseFloat(x),ny=parseFloat(y),v=(isNaN(nx)||isNaN(ny))?String(x).localeCompare(String(y)):nx-ny;return d==='a'?v:-v});r.forEach(function(x){b.appendChild(x)})}
function showpw(id,b){var i=document.getElementById(id);i.type=i.type==='password'?'text':'password';b.textContent=i.type==='password'?'Show':'Hide'}

