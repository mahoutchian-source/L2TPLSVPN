ioctl(TUNSETIFF): Device or resource busy
Error: ipv4: Address already assigned.
>Backup<
--- check
pill OK'>OK</span><span>service strongswan-starter is running
pill OK'>OK</span><span>service xl2tpd is running
pill OK'>OK</span><span>IP forwarding is on
pill OK'>OK</span><span>internet NAT rule present
pill WARN'>WARN</span><span>TCP size fix (MSS clamp to the path MTU) is missing (run: l2tp-gw setup)
pill OK'>OK</span><span>TCP size fix per tunnel, both directions: 0 rules, 0 connection starts looked at
--- logs a / unknown
0
Unknown site
--- backup page + download
Download sites file
Content-Disposition: attachment; filename="l2tp-gw-sites-20261126-094704.conf"
--- restore bad
ERROR: Site &#x27;x&#x27;: bad host &#x27;bad host&#x27;
ERROR: That file is not valid. Nothing was changed.
1
--- restore good
200
[only]
--- restore empty
Paste the file content or choose a file first.
--- reconnect
303
xl2tpd-control disconnect-lac only
ipsec down only
ipsec up only
xl2tpd-control connect-lac only
Reconnecting only. It can take up to a minute to come back.
Unknown site
--- settings
No token saved
bot token looks wrong
Alert after (minutes) must be a number from 1 to 1440.
200
cat: c/notify.conf: No such file or directory
ls: cannot access 'c/notify.conf': No such file or directory
grep: c/notify.conf: No such file or directory
cat: curl.log: No such file or directory
--- csrf missing on new POST routes
reconnect 403
restore 403
settings 403
settings/test 403
