#!/usr/bin/env python3
# holds a persistent tun device open (so it has a carrier and counts the packets sent into it) and throws the packets away
import fcntl, os, struct, sys
fd = os.open("/dev/net/tun", os.O_RDWR)
fcntl.ioctl(fd, 0x400454ca, struct.pack("16sH", sys.argv[1].encode(), 0x0001 | 0x1000))      # TUNSETIFF, IFF_TUN | IFF_NO_PI
while True:
    try:
        os.read(fd, 4096)
    except OSError:
        break
