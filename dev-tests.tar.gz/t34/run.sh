export PATH=$PWD/bin:$PATH CONF_DIR=$PWD/c IPSEC_CONF=$PWD/ipsec.conf IPSEC_D=$PWD/ipd PPP_DIR=$PWD/ppp XL2TPD_CONF=$PWD/x/x.conf SECRETS=$PWD/sec NO_RESTART=1 STATE_DIR=$PWD/st UNIT_DIR=$PWD/units L2TP_GW=$PWD/../build/l2tp-gw SYS_NET=/sys/class/net IPSEC_RECHECK_WAIT=0
GW=$L2TP_GW
rm -rf c ipd ppp x st units ipt calls sec ipsec.conf run cj tg.log ping.log qin qout
mkdir -p c ipd ppp/ip-up.d x st/quality units run
printf '#!/bin/sh\n' > ppp/ip-up; printf '#!/bin/sh\n' > ppp/ip-down
echo "include $IPSEC_D/*.conf" > ipsec.conf
cp ../t8/c/web.conf c/
ok(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fi; }
ip link set lo up
ip link del ppp-cl 2>/dev/null; ip tuntap add dev ppp-cl mode tun; ip addr add 172.17.218.3 peer 172.17.192.3/32 dev ppp-cl; ip link set ppp-cl up
echo "Security Associations (1 up, 0 connecting):" > ipsec.status; echo "cl[1]: ESTABLISHED 3 hours ago" >> ipsec.status
printf 'telegram_token = 123:abc\ntelegram_chat = 55\n' > c/notify.conf
site(){ printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\n%s\n' "$1" > c/sites.conf; }
fill(){ python3 - "$1" "$2" "${3:-0}" <<'PY'
import sys,time
n=int(sys.argv[1]); loss=sys.argv[2]; ol=sys.argv[3]; now=int(time.time())
open("st/quality/cl.log","w").write("".join("%d up %s 20 30 4 %s 18 25 1 1\n"%(now-(n-i)*60,loss,ol) for i in range(n)))
PY
rm -f st/quality/cl.recon st/quality/cl.capmsg st/quality/cl.alert; : > st/watch.log; : > calls; rm -f tg.log; }
sample(){ echo "$1 20 30 4" > qin; echo "${2:-0} 18 30 3" > qout; Q_FORCE=1 bash $GW quality-sample >/dev/null 2>&1; sleep 1.2; }
recon_count(){ [ -f st/quality/cl.recon ] && grep -c . st/quality/cl.recon || echo 0; }
echo "--- validation of the new keys"
site 'poor_loss = abc'; ok "poor_loss = abc refused" "bash $GW apply 2>&1 | grep -q 'poor_loss must be'"
site 'poor_reconnect_min = 5'; ok "poor_reconnect_min = 5 refused (0 or 10-10080)" "bash $GW apply 2>&1 | grep -q 'poor_reconnect_min must be'"
site 'poor_window = 25:00-26:00'; ok "bad poor_window refused" "bash $GW apply 2>&1 | grep -q 'poor_window must look like'"
site 'poor_outside = maybe'; ok "bad poor_outside refused" "bash $GW apply 2>&1 | grep -q 'poor_outside must be yes or no'"
site 'poor_loss = 8
poor_rtt = 500
poor_jitter = 100
poor_alert_min = 10
poor_reconnect_min = 60
poor_cooldown_min = 30
poor_max_day = 3
poor_window = 03:00-07:00
poor_outside = no'; ok "all new keys together are accepted" "! bash $GW apply 2>&1 | grep -q 'must'"
echo "--- automatic reconnect"
site 'poor_reconnect_min = 60'
fill 70 10; sample 10
ok "poor for 60 minutes: reconnect started and logged" "grep -q 'poor for 60 minutes: reconnected automatically (1 of 4 in 24 h)' st/watch.log && grep -q 'disconnect-lac cl' calls"
ok "an event line was written for the panel" "grep -q 'reconnected automatically' st/events.log"
ok "a Telegram message was sent" "grep -q 'reconnected automatically' tg.log"
sample 10
ok "cooldown: no second reconnect right after" "[ \$(recon_count) = 1 ]"
fill 70 10; site 'poor_reconnect_min = 60'; sample 10; [ -f st/quality/cl.recon ] && true
site 'poor_reconnect_min = 0'; fill 70 10; sample 10
ok "poor_reconnect_min = 0 (off): nothing happens" "[ \$(recon_count) = 0 ] && ! grep -q disconnect-lac calls"
site ''; fill 70 10; sample 10
ok "no setting at all (default off): nothing happens" "[ \$(recon_count) = 0 ]"
site 'poor_reconnect_min = 60'; fill 30 10; sample 10
ok "not enough data yet (30 of 60 minutes): nothing happens" "[ \$(recon_count) = 0 ]"
fill 70 0; sample 0
ok "a good link is left alone" "[ \$(recon_count) = 0 ]"
echo "--- per-connection limits"
site 'poor_reconnect_min = 60
poor_loss = 60'; fill 70 10; sample 10
ok "this connection may lose 60%: 10% is not poor, no reconnect" "[ \$(recon_count) = 0 ]"
site 'poor_reconnect_min = 60'; printf 'poor_loss = 60\n' > c/quality.conf; fill 70 10; sample 10
ok "default limit from quality.conf (60%) is used" "[ \$(recon_count) = 0 ]"
printf 'poor_loss = 60\n' > c/quality.conf; site 'poor_reconnect_min = 60
poor_loss = 2'; fill 70 10; sample 10
ok "the connection's own limit (2%) beats the default" "[ \$(recon_count) = 1 ]"
rm -f c/quality.conf
site 'poor_reconnect_min = 60
poor_rtt = 15'; fill 70 0; sample 0
ok "delay limit of this connection (15 ms, delay is 20) makes it poor" "[ \$(recon_count) = 1 ]"
echo "--- guards"
site 'poor_reconnect_min = 60
poor_max_day = 1
poor_cooldown_min = 10'; fill 70 10; echo "$(( $(date +%s) - 3600 ))" > st/quality/cl.recon; sample 10
ok "daily limit reached: no reconnect, one Telegram message that it did not help" "[ \$(recon_count) = 1 ] && grep -q 'did not help' tg.log && grep -q 'limit reached' st/watch.log"
n1=$(grep -c 'did not help' tg.log); sample 10
ok "that message is sent only once a day" "[ \$(grep -c 'did not help' tg.log) = $n1 ]"
S=$(TZ=UTC date -d '+2 hour' +%H:%M); E=$(TZ=UTC date -d '+3 hour' +%H:%M)
site "poor_reconnect_min = 60
poor_window = $S-$E"; fill 70 10; sample 10
ok "outside the time window: no reconnect" "[ \$(recon_count) = 0 ]"
S=$(TZ=UTC date -d '-1 hour' +%H:%M); E=$(TZ=UTC date -d '+1 hour' +%H:%M)
site "poor_reconnect_min = 60
poor_window = $S-$E"; fill 70 10; sample 10
ok "inside the time window: reconnect" "[ \$(recon_count) = 1 ]"
site 'poor_reconnect_min = 60
poor_outside = no'; fill 70 10 10; sample 10 10
ok "poor_outside = no and the road outside is bad too: no reconnect" "[ \$(recon_count) = 0 ]"
fill 70 10; sample 10 0
ok "poor_outside = no and the road outside is fine: reconnect" "[ \$(recon_count) = 1 ]"
echo "--- alert limits per connection"
site 'poor_alert_min = 3'; fill 2 10; sample 10; sample 10; n0=$(grep -c 'POOR for 3 minutes' tg.log)
ok "poor_alert_min = 3: message after 3 poor minutes" "[ \$(grep -c 'POOR for 3 minutes' tg.log) = 1 ]"
site 'poor_alert_min = 3
poor_loss = 60'; fill 2 10; sample 10; sample 10; sample 10
ok "own limit 60%: 10% loss gives no alert" "! grep -q 'POOR' tg.log"
echo "--- panel"
site 'poor_loss = 60'; fill 70 10
python3 -I ../build/l2tp-gw-web run >/dev/null 2>&1 & W=$!; sleep 1.5
B=http://127.0.0.1:18082; J=cj; C=/usr/bin/curl
PW=$(sed -n 's/^password *= *//p' c/web.conf | head -1)
$C -s -c $J -b $J -L --data-urlencode "password=$PW" $B/login > main.html
get(){ $C -s -b $J -c $J "$@"; }
get $B/settings > set.html; get "$B/edit?name=cl" > edit.html; get "$B/conn?name=cl" > conn.html; get $B/quality > q.html
ok "Settings page has the default limits" "grep -q 'name=q_poor_loss' set.html && grep -q 'name=q_poor_reconnect_min' set.html && grep -q 'name=q_poor_window' set.html && grep -q 'name=q_poor_outside' set.html"
ok "site form has the limits and the empty-means-default hint" "grep -q 'name=poor_loss' edit.html && grep -q 'name=poor_reconnect_min' edit.html && grep -q 'Use the default' edit.html"
ok "own value is shown in the site form" "grep -q \"name=poor_loss value='60'\" edit.html"
ok "connection page has the Quality rules card with own limits" "grep -q 'Quality rules' conn.html && grep -q '60% lost' conn.html && grep -q 'has its own limits' conn.html"
ok "the Quality list has no grade word (limits only drive the alert and the reconnect)" "! grep -q 'qgrade' q.html && grep -q 'qrow' q.html"
CS=$(grep -o "name=csrf value='[^']*'" set.html | head -1 | sed "s/.*value='//;s/'//")
$C -s -b $J -c $J -d "csrf=$CS" -d telegram_chat=42 -d down_after_min=5 -d server_name=srv -d dns_flush_min=15 -d q_poor_loss=7 -d q_poor_reconnect_min=120 -d q_poor_window=03:00-05:00 -d q_poor_outside=no $B/settings -o /dev/null
ok "Settings POST writes quality.conf" "grep -q 'poor_loss = 7' c/quality.conf && grep -q 'poor_reconnect_min = 120' c/quality.conf && grep -q 'poor_window = 03:00-05:00' c/quality.conf && grep -q 'poor_outside = no' c/quality.conf"
get $B/settings > set2.html
ok "saved defaults come back in the form" "grep -q \"name=q_poor_loss value='7'\" set2.html"
$C -s -b $J -c $J -d "csrf=$CS" -d telegram_chat=42 -d down_after_min=5 -d server_name=srv -d dns_flush_min=15 -d q_poor_loss=abc $B/settings > bad.html
ok "a wrong default is refused with a message" "grep -q 'Poor loss' bad.html && grep -q 'poor_loss = 7' c/quality.conf"
ok "no python error" "! grep -qi traceback set.html edit.html conn.html q.html"
kill $W
ip link del ppp-cl 2>/dev/null
