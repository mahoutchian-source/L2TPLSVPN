export PATH=$PWD/bin:$PATH CONF_DIR=$PWD/c IPSEC_CONF=$PWD/ipsec.conf IPSEC_D=$PWD/ipd PPP_DIR=$PWD/ppp XL2TPD_CONF=$PWD/x/x.conf SECRETS=$PWD/sec NO_RESTART=1 STATE_DIR=$PWD/st UNIT_DIR=$PWD/units L2TP_GW=$PWD/../build/l2tp-gw SYS_NET=/sys/class/net IPSEC_RECHECK_WAIT=0
GW=$L2TP_GW
rm -rf c ipd ppp x st units ipt calls sec ipsec.conf run cj tg.log ping.log pinglimit pingouter fraglimit
mkdir -p c ipd ppp/ip-up.d x st units run
printf '#!/bin/sh\n' > ppp/ip-up; printf '#!/bin/sh\n' > ppp/ip-down
echo "include $IPSEC_D/*.conf" > ipsec.conf
cp ../t8/c/web.conf c/
ok(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fi; }
ip link set lo up
ip link del ppp-cl 2>/dev/null; ip tuntap add dev ppp-cl mode tun; ip addr add 172.17.218.3 peer 172.17.192.3/32 dev ppp-cl; ip link set ppp-cl up
echo "Security Associations (1 up, 0 connecting):" > ipsec.status; echo "cl[1]: ESTABLISHED 3 hours ago, 1.1.1.1[x]...9.9.9.9[y]" >> ipsec.status
printf 'telegram_token = 123:abc\ntelegram_chat = 55\n' > c/notify.conf
site(){ printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\n%s\n' "$1" > c/sites.conf; }
live(){ cat /sys/class/net/ppp-cl/mtu; }
reset(){ rm -rf st/mtu-auto st/mtu-road; mkdir -p st/mtu-auto; : > st/watch.log; rm -f st/events.log tg.log; }
run(){ bash $GW mtu-auto cl >/dev/null 2>&1; sleep 0.3; }
echo "--- validation"
site 'mtu = auto'; ok "mtu = auto is accepted" "! bash $GW apply 2>&1 | grep -q 'must'"
site 'mtu = auto
mtu_min = 1500
mtu_max = 1300'; ok "mtu_min above mtu_max is refused" "bash $GW apply 2>&1 | grep -q 'mtu_min must not be bigger'"
site 'mtu_margin = abc'; ok "bad mtu_margin refused" "bash $GW apply 2>&1 | grep -q 'mtu_margin must be'"
site 'mtu_max = 100'; ok "mtu_max below 576 refused" "bash $GW apply 2>&1 | grep -q 'mtu_max must be'"
site 'mtu = auto
mtu_min = 1250
mtu_max = 1380
mtu_margin = 25'; ok "range keys accepted" "! bash $GW apply 2>&1 | grep -q 'must'"
ok "pppd gets the top of the range (1380) when auto" "grep -q '^mtu 1380' ppp/options.l2tpd.cl && grep -q '^mru 1380' ppp/options.l2tpd.cl"
site 'mtu = auto'; bash $GW apply >/dev/null 2>&1
ok "default range: pppd gets 1400" "grep -q '^mtu 1400' ppp/options.l2tpd.cl"
printf 'mtu_max = 1360\n' > c/quality.conf; bash $GW apply >/dev/null 2>&1
ok "default from quality.conf is used (1360)" "grep -q '^mtu 1360' ppp/options.l2tpd.cl"
rm -f c/quality.conf
echo "--- the size is set at link up and learned in steps"
site 'mtu = auto'; bash $GW apply >/dev/null 2>&1; reset
ip link set dev ppp-cl mtu 1400; echo 1372 > pinglimit; echo 1472 > pingouter
bash $GW mtu-apply ppp-cl > ma.out 2>&1
ok "link up, nothing learned yet: starts at the bottom of the range (1250)" "[ \$(live) = 1250 ]"
ok "negotiated 1400 = what we offered, so no router limit is recorded" "[ \$(cat st/mtu-auto/cl.mru) = 0 ]"
run
ok "first measurement: nothing changes yet (needs two equal ones)" "[ \$(live) = 1250 ] && [ -f st/mtu-auto/cl.cand ]"
run
ok "second matching measurement: size becomes 1379 (road 1399 minus margin 20)" "[ \$(live) = 1379 ]"
ok "change logged, event written, Telegram sent" "grep -q 'MTU 1250 -> 1379' st/watch.log && grep -q 'automatic MTU' st/events.log && grep -q 'automatic MTU' tg.log"
ok "the learned value is kept" "[ \$(cat st/mtu-auto/cl.set) = 1379 ]"
ok "road info written: outer 1500, inner 1400, suggested 1399, split packets ok" "awk '{ exit !(\$2==1500 && \$3==1400 && \$4==1399 && \$5==\"ok\") }' st/mtu-road/cl"
bash $GW mtu-apply ppp-cl >/dev/null 2>&1
ok "mtu-apply keeps the learned size" "[ \$(live) = 1379 ]"
n=$(grep -c . tg.log); sleep 0.2; run; run
ok "same road again: no change, no new message" "[ \$(live) = 1379 ] && [ \$(grep -c . tg.log) = $n ]"
echo "--- throttle (the watcher calls it every minute)"
: > ping.log; bash $GW mtu-auto >/dev/null 2>&1
ok "a run right after the last one measures nothing" "! grep -q 'ping' ping.log"
echo "--- outside road smaller than the inside: wrapped packets would be split"
echo 1372 > pingouter     # outside carries 1400, tunnel wrapping needs 101 -> 1299
run; run
ok "size goes down to 1279 (1299 - 20)" "[ \$(live) = 1279 ]"
ok "road info shows outer 1400" "awk '{ exit !(\$2==1400) }' st/mtu-road/cl"
echo "--- router limit (MRU)"
reset; echo 1472 > pingouter; echo 1372 > pinglimit
ip link set dev ppp-cl mtu 1300; rm -f st/mtu-auto/cl.applied
bash $GW mtu-apply ppp-cl >/dev/null 2>&1
ok "the router offered 1300 (below our 1400): recorded as its MRU" "[ \$(cat st/mtu-auto/cl.mru) = 1300 ]"
run; run
ok "size is 1300: never above the router limit, and no margin on an exact limit" "[ \$(live) = 1300 ]"
ok "the road info keeps the router limit" "awk '{ exit !(\$6==1300) }' st/mtu-road/cl"
echo "--- router limit below the range"
reset; ip link set dev ppp-cl mtu 1200; rm -f st/mtu-auto/cl.applied
bash $GW mtu-apply ppp-cl >/dev/null 2>&1; run
ok "MRU 1200 below the range 1250: told once" "grep -q 'allows only 1200' tg.log"
run; ok "not told again" "[ \$(grep -c 'allows only 1200' tg.log) = 1 ]"
ok "the size stays at or under the router limit" "[ \$(live) -le 1200 ]"
echo "--- unsafe size is lowered even for a small difference"
reset; site 'mtu = auto
mtu_margin = 0'; ip link set dev ppp-cl mtu 1379; echo 1379 > st/mtu-auto/cl.set 2>/dev/null || { mkdir -p st/mtu-auto; echo 1379 > st/mtu-auto/cl.set; }
echo 1379 > st/mtu-auto/cl.applied; echo 0 > st/mtu-auto/cl.mru; echo 1342 > pinglimit
run; ok "one measurement is not enough" "[ \$(live) = 1379 ]"
run; ok "second one lowers it to 1370 (9 bytes less, but 1379 does not pass)" "[ \$(live) = 1370 ]"
echo "--- no answer, split packets, daily limit"
reset; site 'mtu = auto'; ip link set dev ppp-cl mtu 1300; echo 1300 > pinglimit; echo 1300 > pingouter
mkdir -p st/mtu-auto; echo 1300 > st/mtu-auto/cl.set; echo 1300 > st/mtu-auto/cl.applied; echo 0 > st/mtu-auto/cl.mru
echo 0 > pinglimit
run; run; run
ok "no answer: size untouched, told once after 3 times" "[ \$(live) = 1300 ] && [ \$(grep -c 'no answer' tg.log) = 1 ]"
run; ok "told only once" "[ \$(grep -c 'no answer' tg.log) = 1 ]"
reset; echo 1372 > pinglimit; echo 1472 > pingouter; echo 0 > fraglimit; mkdir -p st/mtu-auto; echo 1300 > st/mtu-auto/cl.applied
run
ok "split packets lost: warning sent" "grep -q 'split packets are lost' tg.log && awk '{ exit !(\$5==\"lost\") }' st/mtu-road/cl"
run; ok "warning only once" "[ \$(grep -c 'split packets are lost' tg.log) = 1 ]"
rm -f fraglimit
reset; printf 'mtu_auto_max_day = 1\n' > c/quality.conf; ip link set dev ppp-cl mtu 1250; echo 1250 > st/mtu-auto/cl.applied 2>/dev/null || { mkdir -p st/mtu-auto; echo 1250 > st/mtu-auto/cl.applied; }
run; run; ok "first change is allowed" "[ \$(live) = 1379 ]"
echo 1300 > pinglimit; run; run
ok "daily limit (1): second change refused and told" "[ \$(live) = 1379 ] && grep -q 'limit of 1 changes' tg.log"
rm -f c/quality.conf
echo "--- manual size is left alone"
reset; site 'mtu = 1300'; rm -f st/mtu-road/cl; ip link set dev ppp-cl mtu 1300; echo 1372 > pinglimit
run; ok "mtu = 1300: no automatic change, nothing recorded" "[ \$(live) = 1300 ] && [ ! -f st/mtu-road/cl ]"
echo "--- health check lines and panel"
reset; site 'mtu = auto'; ip link set dev ppp-cl mtu 1250; mkdir -p st/mtu-auto; echo 1250 > st/mtu-auto/cl.applied
echo 1372 > pinglimit; run; run
bash $GW check > chk.out 2>&1
ok "health: automatic MTU line" "grep -q 'cl: automatic MTU 1379 (range 1250-1400, margin 20)' chk.out"
ok "health: UDP line" "grep -q 'cl: UDP: packets up to 1351 bytes pass whole' chk.out"
ok "no warning when MTU + 101 fits the outside road" "! grep -q 'is more than the outside road' chk.out"
ip link set dev ppp-cl mtu 1450
bash $GW check > chk2.out 2>&1
ok "health: 1450 + 101 > 1500 warns that packets are split outside" "grep -q 'MTU 1450 + about 101 bytes of wrapping = 1551 is more than the outside road (1500)' chk2.out"
ip link set dev ppp-cl mtu 1379
python3 -I ../build/l2tp-gw-web run >/dev/null 2>&1 & W=$!; sleep 1.5
B=http://127.0.0.1:18082; J=cj; C=/usr/bin/curl
PW=$(sed -n 's/^password *= *//p' c/web.conf | head -1)
$C -s -c $J -b $J -L --data-urlencode "password=$PW" $B/login > main.html
$C -s -b $J "$B/conn?name=cl" > conn.html
ok "connection page: automatic MTU, road, split packets" "grep -q 'Automatic MTU' conn.html && grep -q 'Road outside the tunnel' conn.html && grep -q 'Split packets' conn.html"
ok "connection page: no python error" "! grep -qi traceback conn.html"
bash $GW mtu-verify >/dev/null 2>&1
$C -s -b $J "$B/sites" > sites.html; ok "sites list shows MTU auto chip" "grep -q 'MTU auto 1379' sites.html"
$C -s -b $J "$B/edit?name=cl" > edit.html; ok "edit form has auto hint and the range boxes" "grep -q 'name=mtu_min' edit.html && grep -q 'name=mtu_max' edit.html && grep -q 'name=mtu_margin' edit.html"
$C -s -b $J "$B/settings" > set.html; ok "settings has the range defaults and the timing" "grep -q 'name=q_mtu_min' set.html && grep -q 'name=q_mtu_auto_min' set.html"
CS=$(grep -o "name=csrf value='[^']*'" set.html | head -1 | sed "s/.*value='//;s/'//")
$C -s -b $J -c $J -d "csrf=$CS" -d telegram_chat=42 -d down_after_min=5 -d server_name=srv -d dns_flush_min=15 -d q_mtu_min=1300 -d q_mtu_max=1350 -d q_mtu_margin=10 -d q_mtu_auto_min=15 -d q_mtu_auto_max_day=3 $B/settings -o /dev/null
ok "settings saved the range defaults" "grep -q 'mtu_min = 1300' c/quality.conf && grep -q 'mtu_auto_min = 15' c/quality.conf"
$C -s -b $J -c $J -d "csrf=$CS" -d telegram_chat=42 -d down_after_min=5 -d server_name=srv -d dns_flush_min=15 -d q_mtu_min=1400 -d q_mtu_max=1300 $B/settings > set3.html
ok "settings refuses lowest above highest" "grep -q 'lowest MTU must not be bigger' set3.html"
kill $W 2>/dev/null
ip link del ppp-cl 2>/dev/null
