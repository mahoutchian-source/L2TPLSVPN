-rw-r--r-- c/web.crt
-rw------- c/web.key
--- https works (self-signed, -k)
200
--- certificate / protocol
subject=CN = l2tp-gw
--- TLS 1.1 refused
1
--- plain http to the https port does not hang the server
plain http: 000
--- a stalled client does not block others
other client: 200 in 0.005189s
--- cookie has Secure + HttpOnly
Set-Cookie: sid=sLOTzMyqoZ37B4ukwTqgXVmSPFo6OaF-El0sOPHRxt0; HttpOnly; SameSite=Strict; Path=/; Secure
--- lockout: 5 wrong, then even the right password is refused
200 200 200 200 200 
Too many wrong passwords. Try again in 5 minute(s).
429
