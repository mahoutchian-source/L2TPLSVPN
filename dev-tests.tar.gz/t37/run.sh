export PATH=$PWD/bin:$PATH CONF_DIR=$PWD/c IPSEC_CONF=$PWD/ipsec.conf IPSEC_D=$PWD/ipd PPP_DIR=$PWD/ppp XL2TPD_CONF=$PWD/x/x.conf SECRETS=$PWD/sec NO_RESTART=1 STATE_DIR=$PWD/st UNIT_DIR=$PWD/units L2TP_GW=$PWD/../build/l2tp-gw SYS_NET=/sys/class/net IPSEC_RECHECK_WAIT=0
GW=$L2TP_GW
rm -rf c ipd ppp x st units ipt calls sec ipsec.conf run cj tg.log ping.log pinglimit pingouter fraglimit run2 proc l2tp.out
mkdir -p c ipd ppp/ip-up.d x st units run run2 proc
printf '#!/bin/sh\n' > ppp/ip-up; printf '#!/bin/sh\n' > ppp/ip-down
echo "include $IPSEC_D/*.conf" > ipsec.conf
cp ../t8/c/web.conf c/
ok(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fi; }
ip link set lo up
newlink(){ ip link del ppp-cl 2>/dev/null; ip tuntap add dev ppp-cl mode tun; ip addr add 172.17.218.3 peer 172.17.192.3/32 dev ppp-cl; ip link set ppp-cl up; ip link set dev ppp-cl mtu $1; }
newlink 1400
echo "Security Associations (1 up, 0 connecting):" > ipsec.status; echo "cl[1]: ESTABLISHED 3 hours ago, 1.1.1.1[x]...9.9.9.9[y]" >> ipsec.status
printf 'telegram_token = 123:abc\ntelegram_chat = 55\n' > c/notify.conf
site(){ printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\n%s\n' "$1" > c/sites.conf; }
live(){ cat /sys/class/net/ppp-cl/mtu; }
reset(){ rm -rf st/mtu-auto st/mtu-road st/mtu-fixed; mkdir -p st/mtu-auto; : > st/watch.log; rm -f st/events.log tg.log calls; : > ping.log; }
runf(){ bash $GW mtu-auto cl >/dev/null 2>&1; sleep 0.3; }
runn(){ MA_WAIT=0 bash $GW mtu-auto >/dev/null 2>&1; sleep 0.3; }
old(){ echo $(( $(date +%s) - 4000 )) > st/mtu-auto/cl.last; }
echo "--- settings and defaults (nothing fixed in the code)"
site 'mtu = auto'; ok "mtu = auto is accepted" "! bash $GW apply 2>&1 | grep -q 'must'"
site 'mtu_step = 3'; ok "mtu_step below 5 is refused" "bash $GW apply 2>&1 | grep -q 'mtu_step must be'"
site 'mtu_margin = abc'; ok "the old mtu_margin key is ignored" "! bash $GW apply 2>&1 | grep -q 'must'"
site 'mtu_min = 1500
mtu_max = 1300'; ok "mtu_min above mtu_max is refused" "bash $GW apply 2>&1 | grep -q 'mtu_min must not be bigger'"
site ''; bash $GW apply >/dev/null 2>&1
ok "no mtu and nothing in Settings: 1280" "grep -q '^mtu 1280' ppp/options.l2tpd.cl"
printf 'mtu_default_out = 1300\n' > c/quality.conf; bash $GW apply >/dev/null 2>&1
ok "no mtu: the default of Settings (outgoing) is used: 1300" "grep -q '^mtu 1300' ppp/options.l2tpd.cl && grep -q '^mru 1300' ppp/options.l2tpd.cl"
printf 'mtu_default_out = auto\nmtu_max = 1380\n' > c/quality.conf; bash $GW apply >/dev/null 2>&1
ok "Settings default auto: the link starts at the top of the range (1380)" "grep -q '^mtu 1380' ppp/options.l2tpd.cl"
site 'mtu = 1350'; bash $GW apply >/dev/null 2>&1
ok "the own value of the site wins over the default" "grep -q '^mtu 1350' ppp/options.l2tpd.cl"
rm -f c/quality.conf
site 'mtu = auto'; bash $GW apply >/dev/null 2>&1; reset
ok "auto, nothing learned yet: pppd is offered the highest size (1400)" "grep -q '^mtu 1400' ppp/options.l2tpd.cl && grep -q '^mru 1400' ppp/options.l2tpd.cl"
echo "--- a new link: tested about a minute later; passes: left alone"
echo 1372 > pinglimit; : > ping.log
runn; ok "first sight of the link: only noted, nothing sent yet" "! grep -q 'ping' ping.log && [ -f st/mtu-auto/cl.idx ]"
bash $GW mtu-auto >/dev/null 2>&1; ok "less than a minute later (normal wait): still nothing sent" "! grep -q 'ping' ping.log"
runn; ok "after the wait: the 1400 packet passes, size stays 1400 and is remembered" "[ \$(live) = 1400 ] && [ \$(cat st/mtu-auto/cl.set) = 1400 ] && [ ! -f calls ]"
: > ping.log; runn; ok "next minute: nothing is tested again (throttle)" "! grep -q 'ping' ping.log"
echo "--- does not pass: down 20 by 20, then disconnect and connect again"
reset; newlink 1400; echo 1332 > pinglimit
runn; runn
ok "1400 and 1380 fail, 1360 passes: pppd file now offers 1360" "grep -q '^mtu 1360' ppp/options.l2tpd.cl && grep -q '^mru 1360' ppp/options.l2tpd.cl"
ok "the tunnel was disconnected and connected again" "grep -q 'xl2tpd-control disconnect-lac cl' calls && grep -q 'xl2tpd-control connect-lac cl' calls"
ok "change written to the log, the events and Telegram" "grep -q 'MTU 1400 -> 1360' st/watch.log && grep -q 'automatic MTU' st/events.log && grep -q 'MTU 1400 -> 1360' tg.log"
ok "the learned size is kept for the next connect" "[ \$(cat st/mtu-auto/cl.set) = 1360 ]"
echo "--- the tunnel is back at 1360: stays"
newlink 1360; : > calls
runn; runn
ok "1360 passes after the reconnect: no change, no reconnect" "[ \$(live) = 1360 ] && [ ! -s calls ]"
echo "--- 30 minutes later: 20 more passes -> tried by a reconnect"
old; echo 1352 > pinglimit; : > calls
runn
ok "1380 passes the test: pppd file offers 1380, reconnect" "grep -q '^mtu 1380' ppp/options.l2tpd.cl && grep -q 'disconnect-lac cl' calls && [ -f st/mtu-auto/cl.trial ]"
ok "the live link was put back to 1360 after the test" "[ \$(live) = 1360 ]"
newlink 1380; : > calls; echo 1352 > pinglimit
runn; runn
ok "after the reconnect 1380 passes: kept, trial finished, told" "[ \$(live) = 1380 ] && [ ! -f st/mtu-auto/cl.trial ] && grep -q 'MTU 1380 passes after the reconnect' st/watch.log"
echo "--- a try upwards that fails goes back and is not repeated for 6 hours"
old; echo 1372 > pinglimit; : > calls
runn
ok "1400 passes the test: tried (pppd file 1400)" "grep -q '^mtu 1400' ppp/options.l2tpd.cl && [ -f st/mtu-auto/cl.trial ]"
newlink 1400; echo 1352 > pinglimit; : > calls
runn; runn
ok "after the reconnect 1400 does NOT pass: back to 1380 (pppd file and reconnect)" "grep -q '^mtu 1380' ppp/options.l2tpd.cl && grep -q 'disconnect-lac cl' calls && [ ! -f st/mtu-auto/cl.trial ] && [ -f st/mtu-auto/cl.upfail ]"
newlink 1380; : > calls; old; echo 1372 > pinglimit
runn; runn
ok "30 minutes later: no new try upwards (6 hour pause), nothing changes" "[ ! -s calls ] && [ \$(live) = 1380 ]"
echo "--- the highest allowed size was lowered in the settings"
site 'mtu = auto
mtu_max = 1300'; : > calls; old; runf
ok "1380 is above the new top 1300: goes to 1300" "grep -q '^mtu 1300' ppp/options.l2tpd.cl && grep -q 'disconnect-lac cl' calls"
echo "--- nothing in the range passes"
site 'mtu = auto'; reset; newlink 1400; echo 100 > pinglimit
runf; runf
ok "no size passes: told once, size left alone" "[ \$(live) = 1400 ] && [ \$(grep -c 'no size from 1400 down to 1250' tg.log) = 1 ] && [ ! -f calls ]"
echo "--- no answer at all"
reset; echo 0 > pinglimit; runf; runf; runf; runf
ok "no answer: size untouched, told once after 3 times" "[ \$(live) = 1400 ] && [ \$(grep -c 'no answer' tg.log) = 1 ]"
echo "--- road information"
reset; echo 1372 > pinglimit; echo 1472 > pingouter; echo 0 > fraglimit
runf; runf
ok "split packets lost: warning once, road file says lost" "[ \$(grep -c 'split packets are lost' tg.log) = 1 ] && awk '{ exit !(\$5==\"lost\") }' st/mtu-road/cl"
ok "outside road measured from the far router's public address (1500)" "awk '{ exit !(\$2==1500 && \$3==1400) }' st/mtu-road/cl"
rm -f fraglimit
echo "--- a FIXED size is never touched, only watched"
site 'mtu = 1300'; reset; newlink 1300; echo 1372 > pinglimit; rm -f st/mtu-road/cl
runf; ok "fixed 1300: the automatic routine does nothing" "[ \$(live) = 1300 ] && [ ! -f st/mtu-road/cl ] && [ ! -f calls ]"
echo 1200 > pinglimit; QUIET=1 bash $GW mtu-verify >/dev/null 2>&1
ok "one failed check: no alarm yet" "! grep -q 'fixed MTU' tg.log"
QUIET=1 bash $GW mtu-verify >/dev/null 2>&1; sleep 0.3
ok "two failed checks in a row: warned once" "[ \$(grep -c 'fixed MTU' tg.log) = 1 ]"
QUIET=1 bash $GW mtu-verify >/dev/null 2>&1; ok "not warned again" "[ \$(grep -c 'does not pass' tg.log) = 1 ]"
echo 1372 > pinglimit; QUIET=1 bash $GW mtu-verify >/dev/null 2>&1; sleep 0.3
ok "passes again: told" "grep -q 'passes again' tg.log && [ \$(live) = 1300 ]"
echo "--- measure by hand: the size the link has NOW"
site 'mtu = auto'; newlink 1400; echo 1372 > pinglimit
bash $GW mtu-test cl > mt1.out 2>&1
ok "passes: says so, no assumed 1500, RESULT has pass=yes and current=1400" "grep -q 'it PASSES' mt1.out && ! grep -q 'assumed' mt1.out && grep -q 'RESULT.*current=1400 max=1400.*pass=yes' mt1.out"
echo 1332 > pinglimit
bash $GW mtu-test cl > mt2.out 2>&1
ok "does not pass: says so and gives the biggest that does (1360)" "grep -q 'does NOT come back' mt2.out && grep -q '1360 is the biggest size that passes' mt2.out && grep -q 'RESULT.*current=1400 max=1360.*pass=no' mt2.out"
ok "the link was not touched by the test" "[ \$(live) = 1400 ]"
echo 100 > pinglimit
bash $GW mtu-test cl > mt3.out 2>&1
ok "nothing passes: clear sentence" "grep -q 'No size down to 576 passes' mt3.out"
echo "--- dial-in clients: one shared size offered, own side follows the test"
printf 'enabled = yes\npublic_ip = 198.51.100.10\npsk = SharedPsk12345\npool = 10.99.99.0/24\n' > c/dialin.conf
printf '[home]\nmode = server\nuser = hu\npass = hp1234567\nip = 10.99.99.2\nroutes = 192.168.50.0/24\nmtu = auto\nmtu_max = 1450\n\n[mx]\nmode = server\nuser = mu\npass = mp1234567\nip = 10.99.99.3\nroutes = 192.168.60.0/24\nmtu = 1300\n' > c/sites.conf
bash $GW apply > ap.out 2>&1
ok "shared file: the biggest of (auto top 1450, fixed 1300) = 1450, not 1280" "grep -q '^mtu 1450' ppp/options.l2tpd.dialin && grep -q '^mru 1450' ppp/options.l2tpd.dialin"
printf '[home]\nmode = server\nuser = hu\npass = hp1234567\nip = 10.99.99.2\nroutes = 192.168.50.0/24\n' > c/sites.conf
printf 'mtu_default_in = 1320\n' > c/quality.conf
bash $GW apply >/dev/null 2>&1
ok "no mtu on the client: the dial-in default of Settings (1320) is offered" "grep -q '^mtu 1320' ppp/options.l2tpd.dialin"
printf 'mtu_default_in = auto\nmtu_max = 1380\n' > c/quality.conf
bash $GW dialin-sync >/dev/null 2>&1
ok "dialin-sync rewrites only the size lines (auto default: top 1380)" "grep -q '^mtu 1380' ppp/options.l2tpd.dialin && grep -q '^mru 1380' ppp/options.l2tpd.dialin"
rm -f c/quality.conf
printf '[home]\nmode = server\nuser = hu\npass = hp1234567\nip = 10.99.99.2\nroutes = 192.168.50.0/24\nmtu = auto\nmtu_max = 1450\n' > c/sites.conf
bash $GW apply >/dev/null 2>&1
ip link del ppp0 2>/dev/null; ip tuntap add dev ppp0 mode tun; ip addr add 10.99.99.1 peer 10.99.99.2/32 dev ppp0; ip link set ppp0 up; ip link set dev ppp0 mtu 1450
reset; echo 1372 > pinglimit; : > l2tp.out
bash $GW mtu-apply ppp0 >/dev/null 2>&1
ok "link up: starts at the highest allowed size 1450" "[ \$(cat /sys/class/net/ppp0/mtu) = 1450 ]"
MA_WAIT=0 bash $GW mtu-auto >/dev/null 2>&1; sleep 0.3; MA_WAIT=0 bash $GW mtu-auto >/dev/null 2>&1; sleep 0.5
ok "1450 does not pass: 20 by 20 down to 1390, changed in place" "[ \$(cat /sys/class/net/ppp0/mtu) = 1390 ]"
ok "no reconnect for a dial-in client, and the log says so" "[ ! -s calls ] && grep -q 'in place, no reconnect' st/watch.log"
echo $(( $(date +%s) - 4000 )) > st/mtu-auto/home.last; echo 1402 > pinglimit
MA_WAIT=0 bash $GW mtu-auto >/dev/null 2>&1; sleep 0.5
ok "30 minutes later 1410 passes: the dial-in link goes to 1410 in place" "[ \$(cat /sys/class/net/ppp0/mtu) = 1410 ] && [ ! -s calls ]"
echo "--- real connection time and the public address of every client"
sleep 300 & SP=$!; sleep 300 & SP2=$!
mkdir -p proc/$SP; echo $SP > run2/ppp0.pid; printf 'pppd\0plugin\0pppol2tp.so\0pppol2tp_tunnel_id\0004321\0passive\0' > proc/$SP/cmdline
echo $SP2 > run2/ppp-cl.pid
printf 'Tunnel 999, encap UDP\n  From 172.26.10.220 to 1.1.1.1\nTunnel 4321, encap UDP\n  From 172.26.10.220 to 5.6.7.8\n  Peer tunnel 9\n' > l2tp.out
printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\n\n[home]\nmode = server\nuser = hu\npass = hp1234567\nip = 10.99.99.2\nroutes = 192.168.50.0/24\nmtu = auto\n' > c/sites.conf
PPP_RUN=$PWD/run2 PROC_DIR=$PWD/proc bash $GW link-info > li.out 2>&1
ok "link-info: dial-in client has its seconds and its public address 5.6.7.8" "grep -Eq '^home ppp0 [0-9]+ 5\.6\.7\.8$' li.out"
ok "link-info: outgoing site has its seconds, no public address" "grep -Eq '^cl ppp-cl [0-9]+ -$' li.out"
rm -f run2/ppp-cl.pid; PPP_RUN=$PWD/run2 PROC_DIR=$PWD/proc bash $GW link-info > li2.out 2>&1
ok "unknown connection time is written as '-'" "grep -Eq '^cl ppp-cl - -$' li2.out"
printf 'Tunnel 999, encap UDP\n  From 172.26.10.220 to 1.1.1.1\n' > l2tp.out
PPP_RUN=$PWD/run2 PROC_DIR=$PWD/proc bash $GW link-info > li3.out 2>&1
ok "tunnel not in the list: address '-' (never a guess)" "grep -Eq '^home ppp0 [0-9]+ -$' li3.out"
kill $SP $SP2 2>/dev/null
ip link del ppp0 2>/dev/null
echo "--- panel"
printf 'enabled = yes\npublic_ip = 198.51.100.10\npsk = SharedPsk12345\npool = 10.99.99.0/24\n' > c/dialin.conf
printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\nmtu = auto\n\n[home]\nmode = server\nuser = hu\npass = hp1234567\nip = 10.99.99.2\nroutes = 192.168.50.0/24\nmtu = auto\n' > c/sites.conf
rm -f c/quality.conf
bash $GW apply >/dev/null 2>&1
ip tuntap add dev ppp0 mode tun; ip addr add 10.99.99.1 peer 10.99.99.2/32 dev ppp0; ip link set ppp0 up; ip link set dev ppp0 mtu 1400
sleep 300 & SP=$!; mkdir -p proc/$SP; echo $SP > run2/ppp0.pid; printf 'pppd\0plugin\0pppol2tp.so\0pppol2tp_tunnel_id\0004321\0passive\0' > proc/$SP/cmdline
printf 'Tunnel 4321, encap UDP\n  From 172.26.10.220 to 5.6.7.8\n' > l2tp.out
PW=testpass123; sed -i "s/^password = .*/password = $PW/" c/web.conf
export PPP_RUN=$PWD/run2 PROC_DIR=$PWD/proc
python3 -I ../build/l2tp-gw-web run >/dev/null 2>&1 & W=$!; sleep 1.5
B=http://127.0.0.1:18082; J=cj; rm -f $J; C=/usr/bin/curl
$C -s -c $J -b $J -L --data-urlencode "password=$PW" $B/login > main.html
CS=$(grep -o "name=csrf value='[^']*'" main.html | head -1 | sed "s/.*value='//;s/'//")
get(){ $C -s -b $J -c $J "$@"; }
ok "before: the shared size is the default top 1400" "grep -q '^mtu 1400' ppp/options.l2tpd.dialin"
get $B/dialin > di.html
ok "dial-in page: the router address of the connected client is shown" "grep -q 'router address' di.html && grep -q '5.6.7.8' di.html"
ok "dial-in page: real connection time shown (seconds, not the old minute-log guess)" "grep -Eq 'connected for <b>[0-9]+ s</b>' di.html"
ok "dial-in page: no python error" "! grep -qi traceback di.html"
get $B/settings > set.html
ok "settings: step and the two defaults are there, the old margin is gone" "grep -q 'name=q_mtu_step' set.html && grep -q 'name=q_mtu_default_out' set.html && grep -q 'name=q_mtu_default_in' set.html && ! grep -q 'q_mtu_margin' set.html"
$C -s -b $J -c $J -d "csrf=$CS" -d telegram_chat=55 -d down_after_min=5 -d dns_flush_min=30 -d q_mtu_default_out=abc $B/settings > set2.html
ok "settings: a bad MTU default is refused with a clear sentence" "grep -q 'must be auto or a number from 576 to 1500' set2.html"
$C -s -b $J -c $J -d "csrf=$CS" -d telegram_chat=55 -d down_after_min=5 -d dns_flush_min=30 -d q_mtu_default_in=1330 -d q_mtu_max=1330 $B/settings -o /dev/null
ok "settings saved: the default is in quality.conf" "grep -q 'mtu_default_in = 1330' c/quality.conf"
ok "settings saved: the shared size offered to dial-in routers was rewritten at once (top of the range 1400 -> 1330, no restart)" "grep -q '^mtu 1330' ppp/options.l2tpd.dialin && grep -q '^mru 1330' ppp/options.l2tpd.dialin"
get "$B/edit?name=cl" > ed.html
ok "outgoing form: empty MTU = default of Settings, shown" "grep -q 'Empty = the default from Settings' ed.html"
get "$B/conn?name=cl" > cn.html
ok "connection page: no python error and it shows the MTU row" "! grep -qi traceback cn.html && grep -q 'MTU set / link now' cn.html"
kill $W $SP 2>/dev/null
ip link del ppp0 2>/dev/null
echo DONE
