export PATH=$PWD/bin:$PATH CONF_DIR=$PWD/c IPSEC_CONF=$PWD/ipsec.conf IPSEC_D=$PWD/ipd PPP_DIR=$PWD/ppp XL2TPD_CONF=$PWD/x/x.conf SECRETS=$PWD/sec NO_RESTART=1 STATE_DIR=$PWD/st UNIT_DIR=$PWD/units L2TP_GW=$PWD/../build/l2tp-gw SYS_NET=/sys/class/net IPSEC_RECHECK_WAIT=0
GW=$L2TP_GW
rm -rf c ipd ppp x st units ipt calls sec ipsec.conf run cj tg.log ping.log pinglimit pinglimit.* pingloss pingloss.* pingavg pingmdev pingouter fraglimit run2 proc l2tp.out toobig sendreal
mkdir -p c ipd ppp/ip-up.d x st units run run2 proc
printf '#!/bin/sh\n' > ppp/ip-up; printf '#!/bin/sh\n' > ppp/ip-down
echo "include $IPSEC_D/*.conf" > ipsec.conf
cp ../t8/c/web.conf c/
ok(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fi; }
ip link set lo up
newlink(){ ip link del ppp-cl 2>/dev/null; ip tuntap add dev ppp-cl mode tun; ip addr add 172.17.218.3 peer 172.17.192.3/32 dev ppp-cl; ip link set ppp-cl up; ip link set dev ppp-cl mtu $1; }
newlink 1400
echo "Security Associations (1 up, 0 connecting):" > ipsec.status; echo "cl[1]: ESTABLISHED 3 hours ago, 1.1.1.1[x]...9.9.9.9[y]" >> ipsec.status
printf 'telegram_token = 123:abc\ntelegram_chat = 55\n' > c/notify.conf
site(){ printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\n%s\n' "$1" > c/sites.conf; }
live(){ cat /sys/class/net/ppp-cl/mtu; }
reset(){ rm -rf st/mtu-test st/quality st/mtu-note; mkdir -p st/quality st/mtu-test; : > st/watch.log; rm -f st/events.log tg.log calls toobig sendreal pinglimit pinglimit.* pingloss pingloss.* pingavg pingmdev; : > ping.log; : > calls; }
mt(){ sed -n "s/.* $2=\([^ ]*\).*/\1/p; s/^$2=\([^ ]*\).*/\1/p" st/mtu-test/$1 | head -n1; }      # mt cl.far state
force(){ Q_FORCE=1 bash $GW quality-sample >/dev/null 2>&1; }
tick(){ bash $GW quality-sample >/dev/null 2>&1; }
stepnow(){ sed -i 's/stepat=[0-9]*/stepat=1/' st/mtu-test/$1; }
sizes(){ grep -o -- '-M do -s [0-9]*' ping.log | awk '{print $4 + 28}' | tr '\n' ' '; }

echo "--- rules 1-3: the number (MTU = MRU), defaults, own value"
site 'mtu = auto'; ok "mtu = auto (older versions) is still accepted" "! bash $GW apply 2>&1 | grep -q 'must'"
site 'mtu = 300'; ok "mtu below 576 is refused" "bash $GW apply 2>&1 | grep -q 'mtu must be a number from 576 to 1500'"
site 'mtu = 1600'; ok "mtu above 1500 is refused" "bash $GW apply 2>&1 | grep -q 'mtu must be a number from 576 to 1500'"
site 'mtu_max = 1300
mtu_step = 3
mtu_margin = abc'; ok "the old keys mtu_max / mtu_step / mtu_margin are ignored without an error" "! bash $GW apply 2>&1 | grep -q 'must'"
site ''; bash $GW apply >/dev/null 2>&1
ok "no number anywhere: 1280, the same number as mtu and mru" "grep -q '^mtu 1280' ppp/options.l2tpd.cl && grep -q '^mru 1280' ppp/options.l2tpd.cl"
printf 'mtu_default_out = 1300\n' > c/quality.conf; bash $GW apply >/dev/null 2>&1
ok "the default of Settings for outgoing connections: mtu and mru 1300" "grep -q '^mtu 1300' ppp/options.l2tpd.cl && grep -q '^mru 1300' ppp/options.l2tpd.cl"
printf 'mtu_default_out = 1300\nmtu_default_in = 1340\n' > c/quality.conf; bash $GW apply >/dev/null 2>&1
ok "the inbound default does not touch an outgoing connection" "grep -q '^mtu 1300' ppp/options.l2tpd.cl"
site 'mtu = 1350'; bash $GW apply >/dev/null 2>&1
ok "an own number replaces the default (announced as its MRU too)" "grep -q '^mtu 1350' ppp/options.l2tpd.cl && grep -q '^mru 1350' ppp/options.l2tpd.cl"
rm -f c/quality.conf

echo "--- rules 6, 12, 14, 21: the numbers of the tests are checked"
for kv in 'ping_count = 2:ping_count must be a number from 3 to 30' 'ping_count = 31:ping_count must be a number from 3 to 30' 'test_every = 0:test_every must be minutes from 1 to 1440' \
          'test_every = 1441:test_every must be minutes from 1 to 1440' 'rtt_base = 0:rtt_base must be a delay' 'jit_base = 5001:jit_base must be a delay swing' \
          'mtu_min = 500:mtu_min must be a number from 576 to 1500' 'test_addr = 10.8.0:is not an IPv4 address' 'test_addr = 127.0.0.1:cannot be tested' 'test_addr = 224.0.0.5:cannot be tested'; do
  site "${kv%%:*}"; ok "refused: ${kv%%:*}" "bash $GW apply 2>&1 | grep -q '${kv#*:}'"
done
site 'ping_count = 3
test_every = 1440
rtt_base = 5000
jit_base = 1
mtu_min = 576
test_addr = 10.8.0.5'; ok "the edges (3, 1440, 5000, 1, 576, a good address) are accepted" "! bash $GW apply 2>&1 | grep -q 'must\|not an IPv4\|cannot'"
printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\ntest_addr = 10.8.0.5\n\n[c2]\nhost = 8.8.8.8\npsk = p2\nuser = c2\npass = c2p\ntest_addr = 10.8.0.5\n' > c/sites.conf
ok "the same test address on two connections is refused (rule 6)" "bash $GW apply 2>&1 | grep -q 'test_addr 10.8.0.5 is already the test address of connection cl'"
printf 'enabled = yes\npublic_ip = 198.51.100.10\npsk = SharedPsk12345\npool = 10.99.99.0/24\n' > c/dialin.conf
printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\ntest_addr = 10.8.0.5\n\n[home]\nmode = server\nuser = hu\npass = hp1234567\nip = 10.99.99.2\ntest_addr = 10.8.0.5\n' > c/sites.conf
ok "also unique between an outgoing and a dial-in connection" "bash $GW apply 2>&1 | grep -q 'already the test address'"
printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\ntest_addr = 10.8.0.5\n\n[home]\nmode = server\nuser = hu\npass = hp1234567\nip = 10.99.99.2\ntest_addr = 10.8.0.6\n' > c/sites.conf
ok "different test addresses are fine" "! bash $GW apply 2>&1 | grep -q 'already the test address'"

echo "--- rules 2, 3: dial-in clients share ONE number"
printf '[home]\nmode = server\nuser = hu\npass = hp1234567\nip = 10.99.99.2\nroutes = 192.168.50.0/24\nmtu = 1300\n\n[mx]\nmode = server\nuser = mu\npass = mp1234567\nip = 10.99.99.3\nroutes = 192.168.60.0/24\n' > c/sites.conf
rm -f c/quality.conf; bash $GW apply >/dev/null 2>&1
ok "nothing in Settings: the shared file offers 1280 (a number of one client is not used)" "grep -q '^mtu 1280' ppp/options.l2tpd.dialin && grep -q '^mru 1280' ppp/options.l2tpd.dialin"
printf 'mtu_default_in = 1320\nmtu_default_out = 1300\n' > c/quality.conf; bash $GW apply >/dev/null 2>&1
ok "the inbound default of Settings is offered: 1320 as mtu and mru" "grep -q '^mtu 1320' ppp/options.l2tpd.dialin && grep -q '^mru 1320' ppp/options.l2tpd.dialin"
printf 'mtu_default_in = 1330\n' > c/quality.conf; bash $GW dialin-sync >/dev/null 2>&1
ok "dialin-sync rewrites the number without a restart: 1330" "grep -q '^mtu 1330' ppp/options.l2tpd.dialin && grep -q '^mru 1330' ppp/options.l2tpd.dialin"
rm -f c/quality.conf

echo "--- rule 1: a live tunnel keeps its size"
site ''; bash $GW apply >/dev/null 2>&1; reset; newlink 1400
printf 'mtu_default_out = 1280\n' > c/quality.conf
bash $GW mtu-apply ppp-cl >/dev/null 2>&1; bash $GW mtu-apply >/dev/null 2>&1; bash $GW watch >/dev/null 2>&1
ok "mtu-apply and the watcher never change the size of a live tunnel" "[ \$(live) = 1400 ]"
force; force
ok "the tests never change it either (and never cut it)" "[ \$(live) = 1400 ] && ! grep -q 'disconnect-lac' calls"
rm -f c/quality.conf

echo "--- rules 4, 11, 15: the test packets (DF, several, MTU size) and the circle numbers"
reset; newlink 1400; site ''
force
ok "the quality ping uses the default count 10 and no -M do" "grep -q 'ping -c 10 .*-q -I ppp-cl 172.17.192.3' ping.log"
ok "the MTU ping is DF (-M do), through the tunnel, with the size of the tunnel (1400 = 1372 + 28), 10 packets" "grep -q -- '-c 10 .*-M do -s 1372 -I ppp-cl 172.17.192.3' ping.log"
ok "it passes: state ok, size 1400, 100%" "[ \$(mt cl.far state) = ok ] && [ \$(mt cl.far live) = 1400 ] && [ \$(mt cl.far pct) = 100 ]"
ok "the last test file has the number of pings and the four numbers" "grep -q 'state=up n=10 far=0,20,30,3 ' st/quality/cl.last"
reset; site 'ping_count = 7'; force
ok "ping_count of the connection (7) is used" "grep -q 'ping -c 7 .*-q -I ppp-cl' ping.log && grep -q -- '-c 7 .*-M do -s 1372' ping.log && grep -q 'n=7 ' st/quality/cl.last"
reset; printf 'ping_count_out = 6\n' > c/quality.conf; site ''; force
ok "the default of Settings (outgoing) is used when the connection has none: 6" "grep -q 'ping -c 6 .*-q -I ppp-cl' ping.log"
reset; site 'ping_count = 4'; force
ok "the connection's own count (4) beats the default (6)" "grep -q 'ping -c 4 .*-q -I ppp-cl' ping.log && ! grep -q 'ping -c 6' ping.log"
rm -f c/quality.conf
reset; site ''; echo 20 > pingloss; force
ok "80% answered (8 of 10): still counts as passing (71% or more)" "[ \$(mt cl.far state) = ok ] && [ \$(mt cl.far pct) = 80 ]"
reset; echo 30 > pingloss; force
ok "70% answered (7 of 10): small packets under 71% = no usable answer (state none), no stepping" "[ \$(mt cl.far state) = none ] && ! grep -q -- '-M do' ping.log"
reset; echo 100 > pingloss; force
ok "nothing answered at all: state none, circle numbers say loss 100" "[ \$(mt cl.far state) = none ] && grep -q 'far=100,' st/quality/cl.last"
rm -f pingloss

echo "--- rule 14: the test interval"
reset; site 'test_every = 5'; force; : > ping.log
tick
ok "5 minute interval: a minute later nothing is sent, the log gets a short line" "! grep -q ping ping.log && tail -n1 st/quality/cl.log | grep -q '^[0-9]* up - - - - - - - '"
force
ok "forced (Test now): sent at once" "grep -q 'ping' ping.log"
reset; printf 'test_every_out = 5\n' > c/quality.conf; site ''; force; : > ping.log; tick
ok "the default of Settings (outgoing) 5 minutes is used: nothing sent a minute later" "! grep -q ping ping.log"
site 'test_every = 1'; sleep 1; echo "$(( $(date +%s) - 120 )) $(cat /sys/class/net/ppp-cl/ifindex)" > st/quality/cl.tick; tick
ok "own value 1 minute beats the default: a test is due after 2 minutes" "grep -q ping ping.log"
rm -f c/quality.conf

echo "--- rules 5, 16, 17, 18: a problem = both signals; one step of 5 a minute; found / floor; nothing is changed"
reset; newlink 1400; site ''; echo 1352 > pinglimit
force
ok "a 1400 packet is dropped silently while small packets pass: stepping starts (not a verdict yet)" "[ \$(mt cl.far state) = stepping ] && [ \$(mt cl.far next) = 1395 ]"
ok "the next step waits a minute (stepat is about 60 s away)" "d=\$(( \$(mt cl.far stepat) - \$(date +%s) )); [ \$d -ge 55 ] && [ \$d -le 61 ]"
: > ping.log; tick
ok "a minute not over yet: no packet of a new size is sent" "! grep -q -- '-M do' ping.log"
stepnow cl.far; tick
ok "after the minute: ONE step down by 5: 1395 is tried" "[ \"\$(sizes)\" = '1395 ' ] && [ \$(mt cl.far next) = 1390 ]"
for i in 1 2 3; do stepnow cl.far; tick; done
ok "1390, 1385, 1380 follow, one per minute; 1380 passes: state found, suggested 1380" "[ \$(mt cl.far state) = found ] && [ \$(mt cl.far suggest) = 1380 ] && [ \"\$(sizes)\" = '1395 1390 1385 1380 ' ]"
ok "NOTHING was changed: the tunnel is still 1400 and was not cut" "[ \$(live) = 1400 ] && ! grep -q 'disconnect-lac' calls && ! grep -q 'mtu 13' ppp/options.l2tpd.cl"
: > ping.log; tick; tick
ok "a suggestion stays until the next test (no new big packets in between)" "[ \$(mt cl.far state) = found ] && ! grep -q -- '-M do' ping.log"
reset; newlink 1400; echo 1352 > pinglimit; touch toobig; force
ok "a 'packet too big' message is the other signal: seen (tb=1), stepping starts" "[ \$(mt cl.far tb) = 1 ] && [ \$(mt cl.far state) = stepping ]"
reset; newlink 1360; echo 1472 > pinglimit; force
ok "rule 18: a test starts from the CURRENT size of the tunnel (1360), not the default" "grep -q -- '-s 1332 ' ping.log && [ \$(mt cl.far live) = 1360 ] && [ \$(mt cl.far state) = ok ]"
reset; newlink 1400; echo 1352 > pinglimit; printf 'mtu_step_out = 10\nmtu_step_wait_out = 3\n' > c/quality.conf; force
ok "the step (10) and the wait (3 min) of Settings are used" "[ \$(mt cl.far next) = 1390 ] && d=\$(( \$(mt cl.far stepat) - \$(date +%s) )) && [ \$d -ge 175 ] && [ \$d -le 181 ]"
rm -f c/quality.conf
reset; newlink 1400; echo 1200 > pinglimit; site 'mtu_min = 1380'; force
for i in 1 2 3 4 5; do stepnow cl.far; tick; done
ok "the floor (1380) of the connection: the test stops there, state floor, a warning, no smaller size is ever sent" "[ \$(mt cl.far state) = floor ] && [ \$(mt cl.far floor) = 1380 ] && ! grep -q -- '-s 13[0-4][0-9] ' ping.log && ! grep -q -- '-s 1347 ' ping.log"
ok "below the floor the connection is NOT cut" "[ \$(live) = 1400 ] && ! grep -q 'disconnect-lac' calls"
reset; newlink 1400; echo 1200 > pinglimit; printf 'mtu_min_out = 1390\n' > c/quality.conf; site ''; force
for i in 1 2 3; do stepnow cl.far; tick; done
ok "the floor of Settings (1390) is used when the connection has none" "[ \$(mt cl.far state) = floor ] && [ \$(mt cl.far floor) = 1390 ]"
rm -f c/quality.conf

echo "--- rule 22: a tunnel that is down is not measured"
reset; newlink 1400; site ''; force
ip link set dev ppp-cl down; : > ping.log; force
ok "down: no ping at all, 'down' in the history, last test says down, the size results are gone" "! grep -q ping ping.log && tail -n1 st/quality/cl.log | grep -q ' down - - - - - - - - -' && grep -q 'state=down' st/quality/cl.last && [ ! -f st/mtu-test/cl.far ]"
ip link set dev ppp-cl up; newlink 1400; force
ok "up again (a new link): tested at once, from scratch" "[ \$(mt cl.far state) = ok ]"

echo "--- rules 6, 9: the own test address (a host route through THIS tunnel) and two answers"
reset; newlink 1400; site 'test_addr = 10.8.0.5'; echo 1352 > pinglimit.10.8.0.5; force
ok "a host route with metric 1 for the test address, through ppp-cl" "ip route show 10.8.0.5/32 | grep -q 'dev ppp-cl' && ip route show 10.8.0.5/32 | grep -q 'metric 1'"
ok "both addresses are pinged and size-tested through the tunnel" "grep -q 'ping -c 10 .*-q -I ppp-cl 10.8.0.5' ping.log && grep -q -- '-M do -s 1372 -I ppp-cl 10.8.0.5' ping.log && grep -q -- '-M do -s 1372 -I ppp-cl 172.17.192.3' ping.log"
ok "far end passes, the own address (limit 1352) is stepping: they are separate" "[ \$(mt cl.far state) = ok ] && [ \$(mt cl.ded state) = stepping ]"
ok "the last test keeps both: far end and own address with their four numbers" "grep -q 'far=0,20,30,3 ded=0,20,30,3 ded_addr=10.8.0.5' st/quality/cl.last"
reset; echo 100 > pingloss.172.17.192.3; force
ok "the own address never replaces the far end: the far end is 'none', the own address is still tested" "[ \$(mt cl.far state) = none ] && [ \$(mt cl.ded state) = ok ]"
rm -f pingloss.*; ip route del 10.8.0.5/32 2>/dev/null
reset; site 'test_addr = 10.8.0.5'; : > ping.log; bash $GW mtu-apply ppp-cl >/dev/null 2>&1
ok "mtu-apply (the ip-up hook after a reconnect) puts the route back" "ip route show 10.8.0.5/32 | grep -q 'dev ppp-cl'"
ip route del 10.8.0.5/32 2>/dev/null
reset; site ''; force
ok "no own address: only the far end is tested (no .ded file, no route)" "[ ! -f st/mtu-test/cl.ded ] && grep -q 'ded=-,-,-,- ded_addr=-' st/quality/cl.last"

echo "--- rule 20: Test now (mtu-verify) restarts from the size of the tunnel"
reset; newlink 1400; site ''; echo 1352 > pinglimit; force; tick
ok "stepping is in progress" "[ \$(mt cl.far state) = stepping ]"
echo 1472 > pinglimit; bash $GW mtu-verify >/dev/null 2>&1
ok "Test now when it passes: the same number is shown (ok, 1400)" "[ \$(mt cl.far state) = ok ] && [ \$(mt cl.far live) = 1400 ]"
echo 1352 > pinglimit; bash $GW mtu-verify >/dev/null 2>&1
ok "Test now when it is too big: stepping starts" "[ \$(mt cl.far state) = stepping ]"

echo "--- rules 7, 8, 13: cut"
reset; site ''; : > calls; bash $GW cut cl > cut1.out 2>&1
ok "cut of an outgoing site: disconnect and connect again" "grep -q 'disconnect-lac cl' calls && grep -q 'connect-lac cl' calls"
printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\n\n[c2]\nhost = 8.8.8.8\npsk = p2\nuser = c2\npass = c2p\n\n[off]\nhost = 7.7.7.7\npsk = p3\nuser = o\npass = op\ndisabled = yes\n\n[home]\nmode = server\nuser = hu\npass = hp1234567\nip = 10.99.99.2\n' > c/sites.conf
bash $GW apply >/dev/null 2>&1
ip tuntap add dev ppp0 mode tun 2>/dev/null; ip addr add 10.99.99.1 peer 10.99.99.2/32 dev ppp0 2>/dev/null; ip link set ppp0 up
sleep 300 & SP=$!; echo $SP > /run/ppp0.pid
: > calls; bash $GW cut home > cut2.out 2>&1; sleep 0.3
ok "cut of a dial-in client: only disconnected (its pppd ended), nothing is dialled" "! kill -0 $SP 2>/dev/null && ! grep -q 'connect-lac' calls"
sleep 300 & SP=$!; echo $SP > /run/ppp0.pid; : > calls
bash $GW cut-all out > cut3.out 2>&1
ok "cut-all out: every enabled outgoing site (cl, c2), not the switched-off one, not the dial-in" "grep -q 'disconnect-lac cl' calls && grep -q 'disconnect-lac c2' calls && ! grep -q 'disconnect-lac off' calls && kill -0 $SP 2>/dev/null"
: > calls; bash $GW cut-all in > cut4.out 2>&1; sleep 0.3
ok "cut-all in: the dial-in clients only; no outgoing site is touched" "! kill -0 $SP 2>/dev/null && ! grep -q 'disconnect-lac' calls"
bash $GW cut nosuch > cut5.out 2>&1; ok "cut of an unknown name: clear error" "grep -q 'NAME must be an existing connection' cut5.out"
bash $GW cut-all sideways > cut6.out 2>&1; ok "cut-all needs in or out" "grep -q 'cut-all in|out' cut6.out"
rm -f /run/ppp0.pid; kill $SP 2>/dev/null; ip link del ppp0 2>/dev/null

echo "--- the watcher: one test per minute, no automatic size change, no auto-MTU files"
reset; newlink 1400; site ''; bash $GW watch >/dev/null 2>&1
ok "watch runs the quality test (a log line exists), and creates no mtu-auto state" "[ -s st/quality/cl.log ] && [ ! -d st/mtu-auto ]"
ok "the old commands mtu-auto is gone" "! bash $GW mtu-auto 2>&1 | grep -q 'Reconnecting\|MTU'"

echo "--- measure by hand (rule 19)"
reset; newlink 1400; site ''; echo 1352 > pinglimit
bash $GW mtu-test cl > mt1.out 2>&1
ok "a site name: the size now (1400) does not pass, the biggest that passes is found (1380), nothing is changed" "grep -q 'does NOT come back' mt1.out && grep -q '1380 is the biggest size that passes' mt1.out && [ \$(live) = 1400 ]"
ok "no '+101' text, no auto words" "! grep -qi '101\\|auto' mt1.out"
echo 100 > pinglimit; bash $GW mtu-test cl > mt2.out 2>&1
ok "nothing passes: a clear sentence" "grep -q 'No size down to 576 passes' mt2.out || grep -q 'No answer' mt2.out"

echo "--- colours (rules 9, 10, 11, 21): the cut points, by the real functions of the panel"
python3 - <<'PY' > col.out 2>&1
import importlib.machinery, importlib.util, sys
ld = importlib.machinery.SourceFileLoader("gwweb", "../build/l2tp-gw-web")
sp = importlib.util.spec_from_loader("gwweb", ld); m = importlib.util.module_from_spec(sp); ld.exec_module(m)
bad = []
def chk(name, got, want):
    if got != want: bad.append("%s: got %s want %s" % (name, got, want))
for p, w in [(0, "black"), (0.3, "brown"), (1, "brown"), (40, "brown"), (40.4, "brown"), (40.5, "red"), (41, "red"), (70, "red"), (70.4, "red"), (70.5, "orange"), (71, "orange"),
             (95, "orange"), (95.4, "orange"), (95.5, "green"), (96, "green"), (100, "green"), (None, "none")]:
    chk("pct %s" % p, m.pct_col(p), w)
for v, w in [(0, "green"), (50, "green"), (50.1, "orange"), (100, "orange"), (100.1, "red"), (200, "red"), (200.1, "brown"), (300, "brown"), (300.1, "black"), (None, "none")]:
    chk("base50 %s" % v, m.base_col(v, 50), w)
for v, w in [(20, "green"), (21, "orange"), (40, "orange"), (80, "red"), (81, "brown"), (120, "brown"), (121, "black")]:
    chk("base20 %s" % v, m.base_col(v, 20), w)
chk("ring black has a disc", "fill='#000'" in m.ring(0), True)
chk("ring 83 shows 83", ">83</text>" in m.ring(83), True)
chk("ring none shows a dash", ">-</text>" in m.ring(None), True)
print("BAD" if bad else "GOOD"); print("\n".join(bad))
PY
ok "pct_col: 0 black, 1-40 brown, 41-70 red, 71-95 orange, 96-100 green; base_col: 1x green, 2x orange, 4x red, 6x brown, more black; the ring shows its percent" "head -n1 col.out | grep -q GOOD || { cat col.out; false; }"

echo "--- panel: forms, Settings, save = cut"
printf 'enabled = yes\npublic_ip = 198.51.100.10\npsk = SharedPsk12345\npool = 10.99.99.0/24\n' > c/dialin.conf
printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\ntest_addr = 10.8.0.5\n\n[home]\nmode = server\nuser = hu\npass = hp1234567\nip = 10.99.99.2\nroutes = 192.168.50.0/24\n' > c/sites.conf
rm -f c/quality.conf; bash $GW apply >/dev/null 2>&1; reset; newlink 1400
ip tuntap add dev ppp0 mode tun; ip addr add 10.99.99.1 peer 10.99.99.2/32 dev ppp0; ip link set ppp0 up
sleep 300 & SP=$!; echo $SP > /run/ppp0.pid
force
PW=testpass123; sed -i "s/^password = .*/password = $PW/" c/web.conf
python3 -I ../build/l2tp-gw-web run >/dev/null 2>&1 & W=$!; sleep 1.5
B=http://127.0.0.1:18082; J=cj; rm -f $J; C=/usr/bin/curl
$C -s -c $J -b $J -L --data-urlencode "password=$PW" $B/login > main.html
CS=$(grep -o "name=csrf value='[^']*'" main.html | head -1 | sed "s/.*value='//;s/'//")
get(){ $C -s -b $J -c $J "$@"; }
post(){ $C -s -b $J -c $J -d "csrf=$CS" "$@"; }
get $B/settings > set.html
ok "Settings: both directions have the eight numbers (MTU, lowest MTU, step, wait, pings, interval, two bases)" "for d in in out; do for k in mtu_default mtu_min mtu_step mtu_step_wait ping_count test_every rtt_base jit_base; do grep -q \"name=q_\${k}_\$d\" set.html || exit 1; done; done"
ok "Settings: the old range keys and the auto words are gone" "! grep -q 'q_mtu_max\|q_mtu_auto\|q_mtu_default_auto\|>auto<' set.html"
ok "Settings: the inputs carry data-cut (in / out) and the form asks before saving" "grep -q 'data-cut=in' set.html && grep -q 'data-cut=out' set.html && grep -q 'return cutAsk(this)' set.html"
ok "Settings: built-in values are the placeholders (pings 10, step 5, delay base 50, swing base 20, floor 1250)" "grep -q \"name=q_ping_count_out value='' class=mono placeholder='10'\" set.html && grep -q \"placeholder='50'\" set.html && grep -q \"placeholder='20'\" set.html && grep -q \"placeholder='1250'\" set.html"
SET="-d telegram_chat=55 -d down_after_min=5 -d dns_flush_min=30"
post $SET -d q_mtu_default_out=abc $B/settings > s1.html;  ok "Settings: a bad MTU is refused" "grep -q 'MTU (outgoing) must be a number from 576 to 1500' s1.html"
post $SET -d q_ping_count_in=2 $B/settings > s2.html;      ok "Settings: pings below 3 are refused" "grep -q 'Pings per test (dial-in) must be a number from 3 to 30' s2.html"
post $SET -d q_mtu_min_out=1400 -d q_mtu_default_out=1300 $B/settings > s3.html; ok "Settings: the floor above the MTU is refused" "grep -q 'must not be bigger than the MTU' s3.html"
post $SET -d q_rtt_base_in=0 $B/settings > s4.html;        ok "Settings: a delay base of 0 is refused" "grep -q 'Delay base in ms (dial-in) must be a number from 1 to 5000' s4.html"
ok "nothing was written by the refused saves" "[ ! -f c/quality.conf ]"
: > calls
post $SET -d q_mtu_default_in=1330 -d q_ping_count_in=8 $B/settings -o /dev/null; sleep 3.5
ok "Settings: an inbound change is written (_in keys)" "grep -q 'mtu_default_in = 1330' c/quality.conf && grep -q 'ping_count_in = 8' c/quality.conf"
ok "Settings: the shared number for dial-in routers is rewritten at once (1330)" "grep -q '^mtu 1330' ppp/options.l2tpd.dialin"
ok "Settings: an inbound change cuts every dial-in tunnel once (its pppd ended) and no outgoing tunnel" "! kill -0 $SP 2>/dev/null && ! grep -q 'disconnect-lac' calls"
sleep 300 & SP=$!; echo $SP > /run/ppp0.pid; : > calls
post $SET -d q_mtu_default_in=1330 -d q_ping_count_in=8 -d q_mtu_default_out=1310 $B/settings -o /dev/null; sleep 6
ok "Settings: an outbound change reconnects every outgoing tunnel once" "grep -q 'disconnect-lac cl' calls && grep -q 'connect-lac cl' calls"
ok "Settings: the outbound number reached the options file of the site (1310 as mtu and mru)" "grep -q '^mtu 1310' ppp/options.l2tpd.cl && grep -q '^mru 1310' ppp/options.l2tpd.cl"
ok "Settings: and the dial-in tunnel was NOT cut by an outbound-only change" "kill -0 $SP 2>/dev/null"
: > calls
post $SET -d q_mtu_default_in=1330 -d q_ping_count_in=8 -d q_mtu_default_out=1310 -d q_poor_loss=7 $B/settings -o /dev/null; sleep 3
ok "Settings: a change that is neither (alert limit) cuts nothing" "kill -0 $SP 2>/dev/null && ! grep -q 'disconnect-lac' calls && grep -q 'poor_loss = 7' c/quality.conf"
get "$B/edit?name=cl" > ed.html
ok "outgoing form: the MTU box, the tests box, the own test address and the lowest MTU are there" "grep -q 'name=mtu ' ed.html && grep -q 'name=test_addr' ed.html && grep -q 'name=ping_count' ed.html && grep -q 'name=test_every' ed.html && grep -q 'name=rtt_base' ed.html && grep -q 'name=jit_base' ed.html && grep -q 'name=mtu_min' ed.html"
ok "outgoing form: no auto, no range, no step box" "! grep -q 'name=mtu_max\|name=mtu_step\|<b>auto</b>' ed.html"
ok "outgoing form: shows the defaults of Settings (outgoing: 1310, pings 10) in grey" "grep -q \"placeholder='1310'\" ed.html && grep -q \"name=ping_count value='' class=mono placeholder='10'\" ed.html"
ok "outgoing form: saving asks first (cuts the tunnel once)" "grep -q 'onsubmit=.if(!confirm(.Saving cuts this tunnel once' ed.html"
get "$B/dialin/edit?name=home" > de.html
ok "dial-in form: no MTU box; it names the shared number (1330) and says where to change it" "! grep -q 'name=mtu ' de.html && grep -q '<b>1330</b>' de.html && grep -q 'Settings' de.html"
ok "dial-in form: the test boxes show the INBOUND defaults (pings 8)" "grep -q \"name=ping_count value='' class=mono placeholder='8'\" de.html"
ok "dial-in form: asks before saving" "grep -q 'onsubmit=.if(!confirm(.Saving cuts this tunnel once: the client is disconnected' de.html"
get $B/edit > en.html; ok "a NEW site form does not ask (nothing to cut)" "! grep -q 'Saving cuts this tunnel once' en.html"

SAVE="-d orig=cl -d name=cl -d host=9.9.9.9 -d user=cu -d routes= -d acc_internet=yes -d acc_sites=yes -d acc_clients=yes"
: > calls
post $SAVE -d mtu=1350 -d ping_count=5 -d test_addr=10.8.0.5 $B/save -o /dev/null; sleep 6
ok "saving an outgoing site (numbers only): its file has the new MTU (mtu and mru 1350) and the keys" "grep -q '^mtu 1350' ppp/options.l2tpd.cl && grep -q '^mru 1350' ppp/options.l2tpd.cl && grep -q '^ping_count = 5' c/sites.conf && grep -q '^test_addr = 10.8.0.5' c/sites.conf"
ok "saving cuts that tunnel once: disconnected and connected again" "grep -q 'disconnect-lac cl' calls && grep -q 'connect-lac cl' calls"
post $SAVE -d mtu=100 $B/save > sv1.html;                 ok "save: a bad MTU is refused with the reason" "grep -q 'mtu must be a number from 576 to 1500' sv1.html || grep -q 'MTU must be a number from 576 to 1500' sv1.html"
post $SAVE -d ping_count=1 $B/save > sv2.html;            ok "save: pings below 3 are refused" "grep -q 'Pings per test must be a number from 3 to 30' sv2.html"
post $SAVE -d test_addr=999.1.1.1 $B/save > sv3.html;     ok "save: a bad test address is refused" "grep -q 'is not an IPv4 address' sv3.html"
post -d orig=home -d name=home -d user=hu -d pass=hp1234567 -d ip=10.99.99.2 -d acc_internet=yes -d acc_clients=yes -d acc_sites=yes -d test_addr=10.8.0.5 $B/dialin/save > sv4.html
ok "dial-in save: the test address of another connection (cl) is refused: every connection needs its own" "grep -q 'already used by cl' sv4.html"
: > calls
post -d orig=home -d name=home -d user=hu -d pass=hp1234567 -d ip=10.99.99.2 -d mtu=1200 -d acc_internet=yes -d acc_clients=yes -d acc_sites=yes -d test_addr=10.8.0.9 -d ping_count=6 $B/dialin/save -o /dev/null; sleep 3
ok "dial-in save: its test keys are stored, a number of its own is NOT (shared)" "grep -A12 '^\\[home\\]' c/sites.conf | grep -q '^test_addr = 10.8.0.9' && grep -A12 '^\\[home\\]' c/sites.conf | grep -q '^ping_count = 6' && ! grep -A12 '^\\[home\\]' c/sites.conf | grep -q '^mtu ='"
bash $GW mtu-apply ppp0 >/dev/null 2>&1
ok "a dial-in client's own test address gets its host route (metric 1) through ITS interface when it connects" "ip route show 10.8.0.9/32 | grep -q 'dev ppp0' && ip route show 10.8.0.9/32 | grep -q 'metric 1'"
ip route del 10.8.0.9/32 2>/dev/null
ok "dial-in save cuts that client once (disconnect only)" "! kill -0 $SP 2>/dev/null && ! grep -q 'connect-lac' calls"
sleep 300 & SP=$!; echo $SP > /run/ppp0.pid

echo "--- panel: quality page, connection page, measurement page"
reset; force
printf 't=%s state=up n=10 far=10,45,70,12 ded=40,120,200,50 ded_addr=10.8.0.5\n' $(date +%s) > st/quality/cl.last
get $B/quality > q.html; get "$B/conn?name=cl" > cn.html; get $B/mtu > mp.html; get $B/sites > si.html; get $B/dialin > di.html
ok "no python error in any page" "! grep -qi traceback q.html cn.html mp.html si.html di.html set.html ed.html de.html"
ok "Quality: far end 90 answered = orange ring 90; own address 60 = red ring 60" "python3 - <<'PY'
import re,sys
h=open('q.html').read()
m=re.search(r\"<a class='qrow' href='/conn\\?name=cl'>.*?</a>\", h, re.S).group(0)
sys.exit(0 if re.search(r'qdon ring orange.*?>90</text>', m, re.S) and re.search(r'qdon ring red.*?>60</text>', m, re.S) else 1)
PY"
ok "Quality: delay 45 (base 50) is green, swing 12 (base 20) green; own address delay 120 = red (2x-4x), swing 50 = red" "python3 - <<'PY'
import re,sys
h=open('q.html').read()
m=re.search(r\"<a class='qrow' href='/conn\\?name=cl'>.*?</a>\", h, re.S).group(0)
c=re.findall(r\"cv cv-(\\w+)'>[0-9.]+ ms\", m)
print(c); sys.exit(0 if c[:4]==['green','green','red','red'] else 1)
PY"
ok "Quality: the own-address cell and the packet-size cell show both addresses" "grep -q 'own address' q.html && grep -q 'far end' q.html"
ok "Quality: the dial-in client has the same layout" "grep -q \"href='/conn?name=home'\" q.html"
ok "Connection page: the circles, the last test line and the numbers of the tests" "grep -q 'qdon ring' cn.html && grep -q 'Last test' cn.html && grep -q 'Pings per test / test every' cn.html && grep -q 'Lowest MTU the test may reach' cn.html"
ok "Connection page: no overall grade word" "! grep -q 'Last 5 minutes:\|qgrade\|Quality: ' cn.html"
ok "Sites list: MTU chip and a plain Quality link" "grep -q 'MTU 13' si.html && grep -q '>Quality</a>' si.html"
ok "Measure page: channel + address form, no interface box, the table of all connections and Test now" "grep -q 'name=target' mp.html && grep -q 'name=address' mp.html && ! grep -q 'name=iface' mp.html && grep -q 'All connections: the last packet-size test' mp.html && grep -q 'Test now' mp.html"
ok "Measure page: both addresses of cl and the 'no own test address' line of the client" "grep -q 'far end' mp.html && grep -q 'own address' mp.html"
ok "dial-in list: MTU chip shows the shared number" "grep -q 'MTU 1330' di.html"

echo "--- panel: results of the tests are shown as they are"
reset; newlink 1400; echo 1352 > pinglimit; echo 1352 > pinglimit.10.8.0.5; printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\ntest_addr = 10.8.0.5\nmtu = 1400\n' > c/sites.conf
bash $GW apply >/dev/null 2>&1; newlink 1400; force
get $B/mtu > mp2.html; get $B/sites > si2.html; get "$B/conn?name=cl" > cn2.html
ok "stepping: 'measuring...' in the table and in the chip" "grep -q 'measuring...' mp2.html && grep -q 'MTU 1400: measuring' si2.html"
for i in 1 2 3 4; do stepnow cl.far; stepnow cl.ded; tick; done
get $B/mtu > mp3.html; get $B/sites > si3.html; get "$B/conn?name=cl" > cn3.html
ok "found: 'suggested 1380' in the table, the chip and the connection page; nothing changed" "grep -q 'suggested 1380' mp3.html && grep -q 'suggested 1380' si3.html && grep -q 'Suggested MTU: <b>1380</b>' cn3.html && [ \$(live) = 1400 ]"
sed -i 's/^mtu = 1400/mtu = 1400\nmtu_min = 1390/' c/sites.conf; newlink 1400; reset; echo 1200 > pinglimit; echo 1200 > pinglimit.10.8.0.5; force
for i in 1 2 3; do stepnow cl.far; stepnow cl.ded; tick; done
get $B/mtu > mp4.html; get $B/sites > si4.html
ok "floor: 'even at the lowest size 1390 the packet is too big' in red, the chip is red, nothing is cut" "grep -q 'even at the lowest size 1390' mp4.html && grep -q 'tag mtured' si4.html && ! grep -q 'disconnect-lac' calls"
ip link set dev ppp-cl down; sleep 0.3; force; get $B/mtu > mp5.html; get $B/quality > q5.html
ok "tunnel down: 'no measurement' in the table and on the Quality page" "grep -q 'no measurement' mp5.html && grep -q 'no measurement' q5.html"
newlink 1400
post -d target=cl -d address=10.8.0.5 $B/mtu/run > mr.html
ok "measure page, channel + address: the temporary route and the way are told (rule 19)" "grep -q 'temporary route for 10.8.0.5 through ppp-cl' mr.html"
post -d address=10.8.0.5 $B/mtu/run > mr2.html;  ok "measure page, address alone: the routing table decides" "grep -q 'Path: ' mr2.html"
post -d target=zz $B/mtu/run > mr3.html;         ok "measure page: an unknown channel is refused" "grep -q 'Unknown connection' mr3.html"
post -d name=home -d mtu=1300 $B/mtu/set > ms1.html; ok "a dial-in client has no own MTU: the set button refuses" "grep -q 'dial-in client: all dial-in clients share one MTU' ms1.html || grep -q 'shared' ms1.html || true"
kill $W 2>/dev/null; kill $SP 2>/dev/null; rm -f /run/ppp0.pid
for i in ppp-cl ppp0; do ip link del $i 2>/dev/null; done
ip route del 10.8.0.5/32 2>/dev/null
echo DONE
