export PATH=$PWD/bin:$PATH CONF_DIR=$PWD/c IPSEC_CONF=$PWD/ipsec.conf IPSEC_D=$PWD/ipd PPP_DIR=$PWD/ppp XL2TPD_CONF=$PWD/x/x.conf SECRETS=$PWD/sec NO_RESTART=1 STATE_DIR=$PWD/st UNIT_DIR=$PWD/units L2TP_GW=$PWD/../build/l2tp-gw SYS_NET=/sys/class/net IPSEC_RECHECK_WAIT=0
GW=$L2TP_GW
rm -rf c ipd ppp x st units ipt calls sec ipsec.conf run dns
mkdir -p c ipd ppp/ip-up.d x st units run dns
printf '#!/bin/sh\n' > ppp/ip-up; printf '#!/bin/sh\n' > ppp/ip-down
echo "include $IPSEC_D/*.conf" > ipsec.conf
cp ../t8/c/web.conf c/
ok(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fi; }
echo "--- addresses outside the pool: warning only"
printf 'enabled = yes\npublic_ip = 198.51.100.10\npsk = SharedPsk12345\npool = 10.99.99.0/24\nlocal = 172.31.0.1\n' > c/dialin.conf
printf '[a]\nmode = server\nuser = au\npass = apassword1\nip = 10.99.99.2\n\n[b]\nmode = server\nuser = bu\npass = bpassword1\nip = 192.168.77.5\n' > c/sites.conf
bash $GW validate c/sites.conf > v.out 2>&1; rc=$?
ok "a client address outside the pool is accepted" "[ $rc = 0 ]"
bash $GW dialin-warn > w.out 2>&1
ok "warning names the client outside the pool" "grep -q 'WARN  dial-in client b: its address 192.168.77.5 is not inside the pool 10.99.99.0/24' w.out"
ok "no warning for the client inside the pool" "! grep -q 'client a' w.out"
ok "warning for the server's own address outside the pool" "grep -q \"WARN  the server's own address 172.31.0.1 is not inside the pool\" w.out"
bash $GW apply > ap.out 2>&1; rc=$?
ok "apply works with both outside the pool" "[ $rc = 0 ]"
ok "the local ip in xl2tpd is the one given" "grep -q 'local ip = 172.31.0.1' x/x.conf"
ok "chap-secrets has the outside address" "grep -q '192.168.77.5' ppp/chap-secrets"
bash $GW check > chk.out 2>&1
ok "check shows the warnings" "grep -q 'WARN.*dial-in client b' chk.out && grep -q \"WARN.*server's own address\" chk.out"
echo "--- the old loop: change the pool while clients exist"
sed -i 's/^pool = .*/pool = 10.55.0.0\/24/; /^local/d' c/dialin.conf
bash $GW validate c/sites.conf > v2.out 2>&1; rc=$?
ok "a new pool that does not hold the clients is accepted" "[ $rc = 0 ]"
bash $GW dialin-warn > w2.out 2>&1
ok "both clients are warned about" "grep -q 'client a' w2.out && grep -q 'client b' w2.out"
bash $GW apply > ap2.out 2>&1
ok "apply works after the pool change" "[ $? = 0 ] && grep -q 'local ip = 10.55.0.1' x/x.conf"
sed -i 's/^ip = 10.99.99.2/ip = 10.55.0.9/' c/sites.conf
bash $GW dialin-warn > w3.out 2>&1
ok "moving a client into the new pool removes its warning" "! grep -q 'client a' w3.out"
printf '[a]\nmode = server\nuser = au\npass = apassword1\nip = 10.55.0.1\n' > c/sites.conf
bash $GW validate c/sites.conf > v3.out 2>&1
ok "a client may not take the server's own address" "[ $? != 0 ] && grep -q \"the server's own address\" v3.out"
printf '[a]\nmode = server\nuser = au\npass = apassword1\nip = 10.55.0.9\n\n[b]\nmode = server\nuser = bu\npass = bpassword1\nip = 10.55.0.9\n' > c/sites.conf
bash $GW validate c/sites.conf > v4.out 2>&1
ok "two clients may not share an address" "[ $? != 0 ] && grep -q 'already used' v4.out"
ok "dial-in off: no warnings" "sed -i 's/^enabled = yes/enabled = no/' c/dialin.conf; [ -z \"\$(bash $GW dialin-warn)\" ]"
sed -i 's/^enabled = no/enabled = yes/' c/dialin.conf
echo "--- public address as a DNS name"
printf '[a]\nmode = server\nuser = au\npass = apassword1\nip = 10.55.0.9\n' > c/sites.conf
echo 203.0.113.7 > dns/vpn.example.org
sed -i 's/^public_ip = .*/public_ip = vpn.example.org/' c/dialin.conf
bash $GW validate c/sites.conf > v5.out 2>&1
ok "a DNS name is accepted" "[ $? = 0 ]"
bash $GW apply > ap3.out 2>&1
ok "the IPsec identity is the resolved address" "grep -q 'leftid=203.0.113.7' ipd/l2tp-gw-dialin.conf"
ok "the applied address is remembered" "[ \"\$(cat st/dialin.pubip)\" = 203.0.113.7 ]"
sed -i 's/^public_ip = .*/public_ip = bad name!/' c/dialin.conf
bash $GW dialin-sync > v6.out 2>&1
ok "a bad name is refused" "[ $? != 0 ] && grep -q 'neither an IPv4 address nor a DNS name' v6.out"
sed -i 's/^public_ip = .*/public_ip = vpn.example.org/' c/dialin.conf
# the watcher part, run through the real function
w(){ ( source <(sed -n '/^trim()/p;/^dialin_get()/,/^}/p;/^dialin_enabled()/p;/^dialin_pub()/,/^}/p;/^dialin_dns_every()/,/^}/p;/^dialin_dns_watch()/,/^}/p;/^resolve_v4()/p;/^is_ipv4()/p;/^dns_flush_throttled()/,/^}/p' $GW)
  DIALIN=$PWD/c/dialin.conf; STATE_DIR=$PWD/st; WATCH_NEED_APPLY=""; dns_flush_throttled(){ :; }
  dialin_dns_watch; echo "NEED=[$WATCH_NEED_APPLY]" ); }
rm -f st/dialin.dnstime
ok "same address: nothing to do" "[ \"\$(w)\" = 'NEED=[]' ]"
rm -f st/dialin.dnstime; echo 203.0.113.99 > dns/vpn.example.org
ok "a new address is reported (old->new)" "[ \"\$(w)\" = 'NEED=[ dial-in(203.0.113.7->203.0.113.99)]' ]"
ok "the stamp is written" "[ -s st/dialin.dnstime ]"
ok "inside the interval it does not look again" "[ \"\$(w)\" = 'NEED=[]' ]"
printf 'enabled = yes\npublic_ip = vpn.example.org\npsk = SharedPsk12345\npool = 10.55.0.0/24\ndns_every = 5\n' > c/dialin.conf
rm -f st/dialin.dnstime
ok "the interval is the one set" "[ \"\$( ( source <(sed -n '/^trim()/p;/^dialin_get()/,/^}/p;/^dialin_dns_every()/,/^}/p' $GW); DIALIN=$PWD/c/dialin.conf; dialin_dns_every ) )\" = 5 ]"
echo $(( $(date +%s) - 200 )) > st/dialin.dnstime
ok "4 minutes not over: no look" "[ \"\$(w)\" = 'NEED=[]' ]"
echo $(( $(date +%s) - 290 )) > st/dialin.dnstime
ok "5 minutes over: looks and reports" "[ \"\$(w)\" = 'NEED=[ dial-in(203.0.113.7->203.0.113.99)]' ]"
rm -f st/dialin.dnstime dns/vpn.example.org
ok "a name that does not resolve changes nothing" "[ \"\$(w)\" = 'NEED=[]' ]"
ok "it is logged" "grep -q 'does not resolve now' st/watch.log"
ok "the last good address is still used for the config" "[ \"\$( ( source <(sed -n '/^trim()/p;/^dialin_get()/,/^}/p;/^dialin_pub()/,/^}/p;/^resolve_v4()/p;/^is_ipv4()/p' $GW); DIALIN=$PWD/c/dialin.conf; STATE_DIR=$PWD/st; dialin_pub ) )\" = 203.0.113.7 ]"
printf 'enabled = yes\npublic_ip = vpn.example.org\npsk = SharedPsk12345\npool = 10.55.0.0/24\ndns_every = 0\n' > c/dialin.conf
bash $GW dialin-sync > v7.out 2>&1
ok "dns_every 0 is refused" "[ $? != 0 ] && grep -q 'dns_every' v7.out"
printf 'enabled = yes\npublic_ip = 198.51.100.10\npsk = SharedPsk12345\npool = 10.55.0.0/24\n' > c/dialin.conf
rm -f st/dialin.dnstime
ok "a plain IP is never looked up" "[ \"\$(w)\" = 'NEED=[]' ] && [ ! -e st/dialin.dnstime ]"
echo "--- the watcher is wired in"
ok "cmd_watch calls the check" "sed -n '/^cmd_watch()/,/^}/p' $GW | grep -q dialin_dns_watch"
echo "--- panel"
printf 'enabled = yes\npublic_ip = 198.51.100.10\npsk = SharedPsk12345\npool = 10.55.0.0/24\nlocal = 172.31.0.1\n' > c/dialin.conf
printf '[b]\nmode = server\nuser = bu\npass = bpassword1\nip = 192.168.77.5\n' > c/sites.conf
python3 -I ../build/l2tp-gw-web run >/dev/null 2>&1 & W=$!; sleep 1.5
B=http://127.0.0.1:18082; J=cj; C=/usr/bin/curl
PW=$(sed -n 's/^password *= *//p' c/web.conf | head -1)
$C -s -c $J -b $J -L --data-urlencode "password=$PW" $B/login > main.html
$C -s -b $J "$B/dialin" > d.html
ok "settings page has the look-up time field" "grep -q 'name=dns_every' d.html"
ok "no python error" "! grep -qi traceback d.html"
CS=$(grep -o "name=csrf value='[^']*'" d.html | head -1 | sed "s/.*value='//;s/'//")
$C -s -b $J -c $J -L --data-urlencode "csrf=$CS" -d enabled=yes --data-urlencode "public_ip=vpn.example.org" --data-urlencode "psk=" -d pool=10.55.0.0/24 --data-urlencode "local=172.31.0.1" -d dns_every=abc $B/dialin/settings > s1.html
ok "a bad look-up time is refused with a message" "grep -q 'number of minutes from 1 to 1440' s1.html"
$C -s -b $J -c $J -L --data-urlencode "csrf=$CS" -d enabled=yes --data-urlencode "public_ip=vpn.example.org" --data-urlencode "psk=" -d pool=10.55.0.0/24 --data-urlencode "local=172.31.0.1" -d dns_every=3 $B/dialin/settings > s2.html
ok "saved: look-up time written to the file" "grep -q '^dns_every = 3' c/dialin.conf && grep -q '^public_ip = vpn.example.org' c/dialin.conf"
ok "saved page shows the warning about the outside addresses" "grep -q 'Warning' s2.html && grep -q 'client b' s2.html"
kill $W
