export PATH=$PWD/bin:$PATH CONF_DIR=$PWD/c IPSEC_CONF=$PWD/ipsec.conf IPSEC_D=$PWD/ipd PPP_DIR=$PWD/ppp XL2TPD_CONF=$PWD/x/x.conf SECRETS=$PWD/sec NO_RESTART=1 STATE_DIR=$PWD/st UNIT_DIR=$PWD/units L2TP_GW=$PWD/../build/l2tp-gw SYS_NET=/sys/class/net IPSEC_RECHECK_WAIT=0
GW=$L2TP_GW
rm -rf c ipd ppp x st units ipt calls sec ipsec.conf run cj esp
mkdir -p c ipd ppp/ip-up.d x st/quality units run esp
printf '#!/bin/sh\n' > ppp/ip-up; printf '#!/bin/sh\n' > ppp/ip-down
echo "include $IPSEC_D/*.conf" > ipsec.conf
cp ../t8/c/web.conf c/
ok(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fi; }
ip link set lo up
i=0; for n in a b c d; do i=$((i+1)); ip link del ppp-$n 2>/dev/null; ip tuntap add dev ppp-$n mode tun; ip addr add 172.17.$i.3 peer 172.17.$i.9/32 dev ppp-$n; ip link set ppp-$n up; done
echo "Security Associations (4 up, 0 connecting):" > ipsec.status; for n in a b c d; do echo "$n[1]: ESTABLISHED 3 hours ago, 1.1.1.1[x]...9.9.9.9[y]" >> ipsec.status; done
printf '[a]\nhost = 9.9.9.9\npsk = p1\nuser = ua\npass = pa\n\n[b]\nhost = 9.9.9.9\npsk = p1\nuser = ub\npass = pb\n\n[c]\nhost = 8.8.8.8\npsk = p1\nuser = uc\npass = pc\n\n[d]\nhost = 7.7.7.7\npsk = p1\nuser = ud\npass = pd\n' > c/sites.conf
echo "5000 5000" > esp/a; echo "5000 5000" > esp/c; echo "5000 5000" > esp/d; touch esp/c.grow
echo "--- health check: shared address and live encryption test"
bash $GW check > chk.out 2>&1
ok "a and b share the far address: told, naming the other one" "grep -q 'a: shares one IPsec connection with b (same far address 9.9.9.9)' chk.out && grep -q 'b: shares one IPsec connection with a' chk.out"
ok "no ESP counter warning for the shared pair" "! grep -q 'a: PPP is up but ESP counters' chk.out && ! grep -q 'live test' <(grep '^.* [ab]:' chk.out)"
ok "c (own address): live test proves the pings were counted" "grep -q 'c: live test: test pings were counted by IPsec (out +300 B, in +300 B)' chk.out"
ok "d (own address) counters do not grow: warned" "grep -q 'd: live test: pings through the tunnel were answered but its IPsec counters did not grow' chk.out"
ok "c is not told it shares anything" "! grep -q 'c: shares' chk.out"
echo "--- panel: connection time after a hole in the log, headers, cause line"
python3 - <<'PY'
import time
now=int(time.time()); rows=[]
for k in range(120): rows.append("%d up 0 20 30 3 0 18 25 1 1\n"%(now-10800+k*60))       # 3 h ago .. 1 h ago: connected
for k in range(10): rows.append("%d up 0 20 30 3 0 18 25 1 1\n"%(now-540+k*60))        # a hole of nearly 1 h, then 10 minutes
open("st/quality/a.log","w").write("".join(rows))
bad=[]
for k in range(30): bad.append("%d up 20 500 600 200 0 18 25 1 1\n"%(now-1740+k*60))
open("st/quality/c.log","w").write("".join(bad))
open("st/quality/d.log","w").write("".join("%d up 20 500 600 200 30 18 25 1 1\n"%(now-1740+k*60) for k in range(30)))
PY
python3 -I ../build/l2tp-gw-web run >/dev/null 2>&1 & W=$!; sleep 1.5
B=http://127.0.0.1:18082; J=cj; C=/usr/bin/curl
PW=$(sed -n 's/^password *= *//p' c/web.conf | head -1)
$C -s -c $J -b $J -L --data-urlencode "password=$PW" $B/login > main.html
$C -s -b $J "$B/quality" > q.html
ok "no python error" "! grep -qi traceback q.html"
ok "column headers are there" "grep -q '>Connection time<' q.html && grep -q '>Last 24 hours<' q.html && grep -q '>Swing<' q.html"
ok "a: the hole counts as a drop, the connection time restarted (about 10 minutes, not 2 hours)" "python3 - <<'PY'
import re,sys
h=open('q.html').read()
m=re.search(r\"<a class='qrow' href='/conn\?name=a'>.*?</a>\", h, re.S).group(0)
t=re.findall(r'<div><b>([^<]*)</b><small>connected now</small>', m)
print(t)
sys.exit(0 if t and re.fullmatch(r'(9|10) min', t[0]) else 1)
PY"
ok "a: connected time of the last 24 h is shown" "grep -A3 \"name=a'\" q.html | head -0; python3 - <<'PY'
import re,sys
h=open('q.html').read()
m=re.search(r\"<a class='qrow' href='/conn\?name=a'>.*?</a>\", h, re.S).group(0)
sys.exit(0 if re.search(r'<b>[^<]* of [^<]*</b><small>drops in 24 h: 1</small>', m) else 1)
PY"
ok "c: bad inside, good outside: cause line says inside" "grep -q 'Cause: inside the tunnel or the far router' q.html"
ok "d: bad inside and outside: cause line says the road outside" "grep -q 'Cause: the road outside the tunnel is bad too' q.html"
kill $W 2>/dev/null
for n in a b c d; do ip link del ppp-$n 2>/dev/null; done
