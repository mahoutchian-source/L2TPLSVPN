export PATH=$PWD/bin:$PATH CONF_DIR=$PWD/c IPSEC_CONF=$PWD/ipsec.conf IPSEC_D=$PWD/ipd PPP_DIR=$PWD/ppp XL2TPD_CONF=$PWD/x/x.conf SECRETS=$PWD/sec NO_RESTART=1 STATE_DIR=$PWD/st UNIT_DIR=$PWD/units L2TP_GW=$PWD/../build/l2tp-gw SYS_NET=/sys/class/net IPSEC_RECHECK_WAIT=0
GW=$L2TP_GW
rm -rf c ipd ppp x st units ipt calls sec ipsec.conf run cj esp
mkdir -p c ipd ppp/ip-up.d x st/quality units run esp
printf '#!/bin/sh\n' > ppp/ip-up; printf '#!/bin/sh\n' > ppp/ip-down
echo "include $IPSEC_D/*.conf" > ipsec.conf
cp ../t8/c/web.conf c/
ok(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fi; }
ip link set lo up
i=0; for n in a b c d; do i=$((i+1)); ip link del ppp-$n 2>/dev/null; ip tuntap add dev ppp-$n mode tun; ip addr add 172.17.$i.3 peer 172.17.$i.9/32 dev ppp-$n; ip link set ppp-$n up; done
echo "Security Associations (4 up, 0 connecting):" > ipsec.status; for n in a b c d; do echo "$n[1]: ESTABLISHED 3 hours ago, 1.1.1.1[x]...9.9.9.9[y]" >> ipsec.status; done
printf '[a]\nhost = 9.9.9.9\npsk = p1\nuser = ua\npass = pa\n\n[b]\nhost = 9.9.9.9\npsk = p1\nuser = ub\npass = pb\n\n[c]\nhost = 8.8.8.8\npsk = p1\nuser = uc\npass = pc\n\n[d]\nhost = 7.7.7.7\npsk = p1\nuser = ud\npass = pd\n' > c/sites.conf
echo "5000 5000" > esp/a; echo "5000 5000" > esp/c; echo "5000 5000" > esp/d; touch esp/c.grow
echo "--- health check: shared address and live encryption test"
bash $GW check > chk.out 2>&1
ok "a and b share the far address: told, naming the other one" "grep -q 'a: shares one IPsec connection with b (same far address 9.9.9.9)' chk.out && grep -q 'b: shares one IPsec connection with a' chk.out"
ok "no ESP counter warning for the shared pair" "! grep -q 'a: PPP is up but ESP counters' chk.out && ! grep -q 'live test' <(grep '^.* [ab]:' chk.out)"
ok "c (own address): live test proves the pings were counted" "grep -q 'c: live test: test pings were counted by IPsec (out +300 B, in +300 B)' chk.out"
ok "d (own address) counters do not grow: warned" "grep -q 'd: live test: pings through the tunnel were answered but its IPsec counters did not grow' chk.out"
ok "c is not told it shares anything" "! grep -q 'c: shares' chk.out"
echo "--- panel: connection time after a hole in the log, headers, cause line"
python3 - <<'PY'
import time
now=int(time.time()); rows=[]
for k in range(120): rows.append("%d up 0 20 30 3 0 18 25 1 1\n"%(now-10800+k*60))       # 3 h ago .. 1 h ago: connected
for k in range(10): rows.append("%d up 0 20 30 3 0 18 25 1 1\n"%(now-540+k*60))        # a hole of nearly 1 h, then 10 minutes
open("st/quality/a.log","w").write("".join(rows))
bad=[]
for k in range(30): bad.append("%d up 20 500 600 200 0 18 25 1 1\n"%(now-1740+k*60))
open("st/quality/c.log","w").write("".join(bad))
open("st/quality/d.log","w").write("".join("%d up 20 500 600 200 30 18 25 1 1\n"%(now-1740+k*60) for k in range(30)))
PY
now=$(date +%s)
printf 't=%s state=up n=10 far=20,500,600,200 ded=-,-,-,- ded_addr=-\n' $now > st/quality/c.last
printf 't=%s state=up n=10 far=100,-,-,- ded=-,-,-,- ded_addr=-\n' $now > st/quality/d.last
printf 't=%s state=up n=10 far=0,20,30,3 ded=-,-,-,- ded_addr=-\n' $now > st/quality/a.last
python3 -I ../build/l2tp-gw-web run >/dev/null 2>&1 & W=$!; sleep 1.5
B=http://127.0.0.1:18082; J=cj; C=/usr/bin/curl
PW=$(sed -n 's/^password *= *//p' c/web.conf | head -1)
$C -s -c $J -b $J -L --data-urlencode "password=$PW" $B/login > main.html
$C -s -b $J "$B/quality" > q.html
ok "no python error" "! grep -qi traceback q.html"
ok "column headers are there" "grep -q '>Connection time<' q.html && grep -q '>Last 24 hours<' q.html && grep -q '>Far end<' q.html && grep -q '>Own test address<' q.html && grep -q '>Packet size<' q.html"
ok "a: the hole counts as a drop, the connection time restarted (about 10 minutes, not 2 hours)" "python3 - <<'PY'
import re,sys
h=open('q.html').read()
m=re.search(r\"<a class='qrow' href='/conn\?name=a'>.*?</a>\", h, re.S).group(0)
t=re.findall(r'<div><b>([^<]*)</b><small>connected now</small>', m)
print(t)
sys.exit(0 if t and re.fullmatch(r'(9|10) min', t[0]) else 1)
PY"
ok "a: last 24 h is a ring with a percent and two short lines (history is about 3 h, so it says so)" "python3 - <<'PY'
import re,sys
h=open('q.html').read()
m=re.search(r\"<a class='qrow' href='/conn\\?name=a'>.*?</a>\", h, re.S).group(0)
ok = ('class=\'qdon' in m and 'stroke-dasharray' in m and 'connected, of 3 h' in m and 'dropped 1 time<' in m)
print(bool(ok)); sys.exit(0 if ok else 1)
PY"
ok "page: the live list is not swapped when nothing changed or the mouse is busy" "grep -q 'LASTPTR' q.html && grep -q '__last===j.html' q.html"
ok "page: the speed block has a fixed two-line height" "grep -q 'div.speed{min-height:2.7em}' q.html && grep -q 'svg.spark:empty{visibility:hidden}' q.html"
ok "c: 20% lost = 80 answered = orange ring with 80 in the middle" "python3 - <<'PY'
import re,sys
h=open('q.html').read()
m=re.search(r\"<a class='qrow' href='/conn\\?name=c'>.*?</a>\", h, re.S).group(0)
sys.exit(0 if re.search(r'qdon ring orange.*?>80</text>', m, re.S) else 1)
PY"
ok "c: delay 500 ms and swing 200 ms are far above 6x the bases (50, 20): black" "python3 - <<'PY'
import re,sys
h=open('q.html').read()
m=re.search(r\"<a class='qrow' href='/conn\\?name=c'>.*?</a>\", h, re.S).group(0)
sys.exit(0 if len(re.findall(r'cv cv-black', m)) >= 2 else 1)
PY"
ok "d: no ping answered = black ring with 0" "python3 - <<'PY'
import re,sys
h=open('q.html').read()
m=re.search(r\"<a class='qrow' href='/conn\\?name=d'>.*?</a>\", h, re.S).group(0)
sys.exit(0 if re.search(r'qdon ring black.*?>0</text>', m, re.S) else 1)
PY"
ok "a: all answered = green ring with 100" "python3 - <<'PY'
import re,sys
h=open('q.html').read()
m=re.search(r\"<a class='qrow' href='/conn\\?name=a'>.*?</a>\", h, re.S).group(0)
sys.exit(0 if re.search(r'qdon ring green.*?>100</text>', m, re.S) else 1)
PY"
ok "no cause line or grade word any more" "! grep -q 'Cause: ' q.html && ! grep -q 'qgrade' q.html"
kill $W 2>/dev/null
for n in a b c d; do ip link del ppp-$n 2>/dev/null; done
