ioctl(TUNSETIFF): Device or resource busy
Error: ipv4: Address already assigned.
runweb2.sh: line 5: c/sites.conf: No such file or directory
No password set. Run: l2tp-gw-web install
default (heal), plain L2TP:   
grep: c/sites.conf: No such file or directory
save allow:   http 000   file: 
allow:          chip: 
edit form:    
grep: c/sites.conf: No such file or directory
save require: http 000   file: 
require:        chip: 
grep: c/sites.conf: No such file or directory
save heal:    http 000   lines with ipsec_mode in file: 
heal again:     chip: 0
forged value: 
runweb2.sh: line 23: kill: (16205) - No such process
