export PATH=$PWD/bin:$PATH CONF_DIR=$PWD/c IPSEC_CONF=$PWD/ipsec.conf IPSEC_D=$PWD/ipd PPP_DIR=$PWD/ppp XL2TPD_CONF=$PWD/x/x.conf SECRETS=$PWD/sec NO_RESTART=1 STATE_DIR=$PWD/st UNIT_DIR=$PWD/units L2TP_GW=$PWD/../build/l2tp-gw SYS_NET=/sys/class/net IPSEC_RECHECK_WAIT=0
GW=$L2TP_GW
rm -rf c ipd ppp x st units ipt calls sec ipsec.conf run
mkdir -p c ipd ppp/ip-up.d x st units run
printf '#!/bin/sh\n' > ppp/ip-up; printf '#!/bin/sh\n' > ppp/ip-down
echo "include $IPSEC_D/*.conf" > ipsec.conf
cp ../t8/c/web.conf c/
ok(){ if eval "$2"; then echo "PASS $1"; else echo "FAIL $1"; fi; }
ip link set lo up
for i in ppp-cl ppp0; do ip link del $i 2>/dev/null; done
ip tuntap add dev ppp-cl mode tun; ip addr add 172.17.218.3 peer 172.17.192.3/32 dev ppp-cl; ip link set ppp-cl up; ip link set dev ppp-cl mtu 1350
ip tuntap add dev ppp0 mode tun; ip addr add 10.99.99.1 peer 10.99.99.2/32 dev ppp0; ip link set ppp0 up; ip link set dev ppp0 mtu 1280
echo "Security Associations (1 up, 0 connecting):" > ipsec.status; echo "cl[1]: ESTABLISHED 3 hours ago, 1.1.1.1[x]...9.9.9.9[y]" >> ipsec.status
printf 'enabled = yes\npublic_ip = 198.51.100.10\npsk = SharedPsk12345\npool = 10.99.99.0/24\n' > c/dialin.conf
printf '[cl]\nhost = 9.9.9.9\npsk = p1\nuser = cu\npass = cp\n\n[hm]\nmode = server\nuser = hmuser\npass = hmpassword1\nip = 10.99.99.2\n' > c/sites.conf
echo "--- mss-apply"
bash $GW mss-apply > mss.out 2>&1
ok "rules for both tunnels, both directions, MTU - 40" "grep -qx 'A L2TPGW-MSS -i ppp-cl -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --set-mss 1310' ipt/rules && grep -qx 'A L2TPGW-MSS -o ppp-cl -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --set-mss 1310' ipt/rules && grep -qx 'A L2TPGW-MSS -i ppp0 -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --set-mss 1240' ipt/rules && grep -qx 'A L2TPGW-MSS -o ppp0 -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --set-mss 1240' ipt/rules"
ok "chain is hooked into FORWARD" "grep -qx 'A FORWARD -j L2TPGW-MSS' ipt/rules"
ok "signature file written" "grep -q 'ppp-cl:1350' st/mss-sig"
n=$(wc -l < ipt/calls); bash $GW mss-apply >/dev/null 2>&1; n2=$(wc -l < ipt/calls)
ok "second call with nothing changed does not rebuild (only checks)" "! tail -n +\$((n+1)) ipt/calls | grep -q -- '-A L2TPGW-MSS'"
ip link set dev ppp-cl mtu 1400
bash $GW mss-apply >/dev/null 2>&1
ok "an MTU change rebuilds with the new size" "grep -qx 'A L2TPGW-MSS -i ppp-cl -p tcp --tcp-flags SYN,RST SYN -j TCPMSS --set-mss 1360' ipt/rules && ! grep -q 'ppp-cl .*--set-mss 1310' ipt/rules"
ok "rebuild leaves no duplicate rules" "[ \$(grep -c '^A L2TPGW-MSS -i ppp-cl ' ipt/rules) = 1 ]"
echo "--- hooks and watcher"
bash $GW dialin-sync >/dev/null 2>&1
ok "mtu-apply (called by the ip-up hook) also refreshes the MSS rules" "grep -q 'mtu-apply' ppp/ip-up.d/l2tp-gw && grep -n 'cmd_mss_apply' ../build/l2tp-gw | grep -q mtu_ONLY_unused || grep -q 'cmd_mss_apply || true' ../build/l2tp-gw"
ok "watcher runs mss-apply" "grep -q 'mss-apply >/dev/null' ../build/l2tp-gw"
echo "--- health check lines"
bash $GW check > chk.out 2>&1
ok "server line: generic clamp present" "grep -q 'TCP size fix for forwarded traffic is on' chk.out"
ok "server line: per tunnel rules counted" "grep -q 'TCP size fix per tunnel, both directions: 4 rules' chk.out"
ok "server line: ICMP not blocked" "grep -q \"ICMP 'packet too big' messages are not blocked\" chk.out"
ok "site line: MSS 1360 both ways" "grep -q 'cl: TCP size (MSS) is cut to 1360 both ways (link MTU 1400)' chk.out"
printf 'x\n' > /dev/null
rm -f ipt/rules; bash $GW check > chk2.out 2>&1
ok "no rules: warning with the command to run" "grep -q 'WARN.*cl: no TCP size rule for ppp-cl' chk2.out && grep -q 'WARN.*per tunnel is not set yet' chk2.out"
echo "A INPUT -p icmp -j DROP" >> ipt/rules; bash $GW check > chk3.out 2>&1
ok "a firewall rule dropping ICMP gives a warning" "grep -q 'WARN.*firewall rule drops ICMP' chk3.out"
echo "A INPUT -p icmp -m icmp --icmp-type echo-request -j DROP" > ipt/rules2; grep -v 'p icmp -j DROP' ipt/rules > ipt/r3; cat ipt/rules2 >> ipt/r3; mv ipt/r3 ipt/rules; bash $GW check > chk4.out 2>&1
ok "dropping only ping (echo-request) is fine" "grep -q \"OK.*ICMP 'packet too big' messages are not blocked\" chk4.out"
echo "--- panel"
python3 -I ../build/l2tp-gw-web run >/dev/null 2>&1 & W=$!; sleep 1.5
B=http://127.0.0.1:18082; J=cj; C=/usr/bin/curl
PW=$(sed -n 's/^password *= *//p' c/web.conf | head -1)
$C -s -c $J -b $J -L --data-urlencode "password=$PW" $B/login > main.html
$C -s -b $J "$B/conn?name=cl" > conn.html
ok "connection page shows MSS and the biggest UDP packet" "grep -q 'TCP segment size (MSS)' conn.html && grep -q '1360 bytes (link MTU - 40)' conn.html && grep -q '1372 bytes (link MTU - 28)' conn.html"
ok "no python error" "! grep -qi traceback conn.html"
kill $W
for i in ppp-cl ppp0; do ip link del $i 2>/dev/null; done
